"use client";
// ===== STREAK — Dynamic Scene Background =====
import React, { useMemo } from "react";
import type { GameState } from "@/lib/game/types";
import { AREAS } from "@/lib/game/data";
import { isNight, dragonAgeDays } from "@/lib/game/engine";

interface Props {
  state: GameState;
}

export default function Scene({ state }: Props) {
  const night = isNight();
  const area = AREAS.find((a) => a.id === state.areas.current) || AREAS[0];
  const ageDays = state.dragon ? dragonAgeDays(state.dragon) : 0;
  const raining = state.events.some((e) => e.type === "rain");
  const meteor = state.events.some((e) => e.type === "meteor");
  const birthday = state.events.some((e) => e.type === "birthday");

  // Background development tier based on age
  const tier = useMemo(() => {
    if (ageDays >= 365) return "kingdom";
    if (ageDays >= 100) return "castle";
    if (ageDays >= 30) return "trees";
    if (ageDays >= 7) return "saplings";
    return "grass";
  }, [ageDays]);

  // Sky colors: day vs night, modified by area
  const skyTop = night ? shade(area.skyTop, -55) : area.skyTop;
  const skyBottom = night ? shade(area.skyBottom, -50) : area.skyBottom;
  const groundColor = night ? shade(area.ground, -35) : area.ground;

  return (
    <div className="absolute inset-0 overflow-hidden" style={{ background: `linear-gradient(to bottom, ${skyTop} 0%, ${skyBottom} 70%, ${groundColor} 70%, ${shade(groundColor, -15)} 100%)` }}>
      {/* Stars at night */}
      {night && (
        <div className="absolute inset-0">
          {Array.from({ length: 40 }).map((_, i) => (
            <div
              key={i}
              className="absolute rounded-full bg-white streak-twinkle"
              style={{
                left: `${(i * 37) % 100}%`,
                top: `${(i * 23) % 60}%`,
                width: `${1 + (i % 3)}px`,
                height: `${1 + (i % 3)}px`,
                animationDelay: `${(i % 5) * 0.4}s`,
                opacity: 0.6 + (i % 4) * 0.1,
              }}
            />
          ))}
        </div>
      )}

      {/* Sun / Moon */}
      {night ? (
        <div className="absolute streak-moon-float" style={{ top: "8%", right: "12%" }}>
          <svg width="70" height="70" viewBox="0 0 70 70">
            <circle cx="35" cy="35" r="28" fill="#fef3c7" />
            <circle cx="28" cy="30" r="4" fill="#fde68a" opacity="0.6" />
            <circle cx="42" cy="40" r="3" fill="#fde68a" opacity="0.6" />
            <circle cx="38" cy="25" r="2" fill="#fde68a" opacity="0.6" />
          </svg>
        </div>
      ) : (
        <div className="absolute streak-sun-glow" style={{ top: "6%", right: "10%" }}>
          <svg width="80" height="80" viewBox="0 0 80 80">
            <circle cx="40" cy="40" r="22" fill="#fde047" />
            <circle cx="40" cy="40" r="28" fill="#fef08a" opacity="0.4" />
            <circle cx="40" cy="40" r="34" fill="#fef9c3" opacity="0.2" />
          </svg>
        </div>
      )}

      {/* Clouds */}
      {!raining && (
        <div className="absolute inset-0 pointer-events-none">
          {[0, 1, 2, 3].map((i) => (
            <div
              key={i}
              className="absolute streak-cloud-drift"
              style={{
                top: `${10 + i * 8}%`,
                left: `${(i * 28) % 100}%`,
                animationDuration: `${40 + i * 15}s`,
                animationDelay: `${i * 5}s`,
                opacity: night ? 0.3 : 0.8,
              }}
            >
              <Cloud />
            </div>
          ))}
        </div>
      )}

      {/* Meteor */}
      {meteor && (
        <div className="absolute streak-meteor" style={{ top: "10%", left: "60%" }}>
          <div className="text-3xl">🌠</div>
        </div>
      )}

      {/* Birthday banner */}
      {birthday && (
        <div className="absolute top-4 left-1/2 -translate-x-1/2 streak-bounce z-10">
          <div className="bg-pink-500 text-white px-4 py-1.5 rounded-full text-sm font-bold shadow-lg flex items-center gap-1">
            🎂 Selamat Ulang Tahun!
          </div>
        </div>
      )}

      {/* Rain */}
      {raining && (
        <div className="absolute inset-0 pointer-events-none">
          {Array.from({ length: 60 }).map((_, i) => (
            <div
              key={i}
              className="absolute streak-rain"
              style={{
                left: `${(i * 13) % 100}%`,
                top: `${-10 + ((i * 7) % 30)}%`,
                animationDelay: `${(i % 10) * 0.1}s`,
                animationDuration: `${0.5 + (i % 3) * 0.2}s`,
              }}
            />
          ))}
        </div>
      )}

      {/* Background scenery based on area + tier */}
      <div className="absolute bottom-0 left-0 right-0" style={{ height: "35%" }}>
        {/* Area-specific scenery */}
        {area.id === "meadow" && <MeadowScene tier={tier} night={night} />}
        {area.id === "forest" && <ForestScene tier={tier} night={night} />}
        {area.id === "mountain" && <MountainScene tier={tier} night={night} />}
        {area.id === "volcanic" && <VolcanicScene tier={tier} night={night} />}
        {area.id === "sky" && <SkyScene tier={tier} night={night} />}
        {area.id === "crystal" && <CrystalScene tier={tier} night={night} />}
        {area.id === "ocean" && <OceanScene tier={tier} night={night} />}
      </div>

      {/* Ground shadow under dragon */}
      <div className="absolute" style={{ bottom: "16%", left: "50%", transform: "translateX(-50%)" }}>
        <div className="w-32 h-4 rounded-full bg-black/20 blur-sm" />
      </div>

      {/* Ambient overlay */}
      {night && <div className="absolute inset-0 bg-indigo-950/20 pointer-events-none" />}
      {raining && <div className="absolute inset-0 bg-slate-400/10 pointer-events-none" />}
    </div>
  );
}

function shade(hex: string, percent: number): string {
  // shade a hex color by percent (-100..100)
  if (hex === "rainbow" || !hex.startsWith("#")) return hex;
  const num = parseInt(hex.slice(1), 16);
  const r = Math.max(0, Math.min(255, (num >> 16) + Math.round((percent / 100) * 255)));
  const g = Math.max(0, Math.min(255, ((num >> 8) & 0xff) + Math.round((percent / 100) * 255)));
  const b = Math.max(0, Math.min(255, (num & 0xff) + Math.round((percent / 100) * 255)));
  return `#${((r << 16) | (g << 8) | b).toString(16).padStart(6, "0")}`;
}

function Cloud() {
  return (
    <svg width="100" height="50" viewBox="0 0 100 50">
      <ellipse cx="30" cy="30" rx="22" ry="16" fill="white" />
      <ellipse cx="55" cy="25" rx="26" ry="20" fill="white" />
      <ellipse cx="75" cy="32" rx="18" ry="14" fill="white" />
      <ellipse cx="45" cy="38" rx="24" ry="10" fill="white" />
    </svg>
  );
}

function Tree({ x, scale = 1, night = false }: { x: number; scale?: number; night?: boolean }) {
  return (
    <div className="absolute bottom-0" style={{ left: `${x}%`, transform: `scale(${scale})`, transformOrigin: "bottom" }}>
      <svg width="60" height="90" viewBox="0 0 60 90">
        <rect x="26" y="55" width="8" height="35" fill={night ? "#451a03" : "#78350f"} />
        <circle cx="30" cy="40" r="22" fill={night ? "#14532d" : "#16a34a"} />
        <circle cx="18" cy="48" r="14" fill={night ? "#14532d" : "#16a34a"} />
        <circle cx="42" cy="48" r="14" fill={night ? "#14532d" : "#16a34a"} />
        <circle cx="30" cy="28" r="14" fill={night ? "#166534" : "#22c55e"} />
      </svg>
    </div>
  );
}

function Castle({ x, night = false }: { x: number; night?: boolean }) {
  return (
    <div className="absolute bottom-0" style={{ left: `${x}%`, transform: "translateX(-50%)" }}>
      <svg width="120" height="110" viewBox="0 0 120 110">
        <rect x="20" y="40" width="80" height="70" fill={night ? "#475569" : "#94a3b8"} />
        <rect x="10" y="55" width="15" height="55" fill={night ? "#334155" : "#64748b"} />
        <rect x="95" y="55" width="15" height="55" fill={night ? "#334155" : "#64748b"} />
        <rect x="50" y="20" width="20" height="30" fill={night ? "#334155" : "#64748b"} />
        <polygon points="50,20 60,5 70,20" fill={night ? "#7c2d12" : "#dc2626"} />
        <rect x="55" y="60" width="10" height="20" fill={night ? "#1e293b" : "#1e293b"} />
        <circle cx="60" cy="8" r="2" fill="#fbbf24" />
      </svg>
    </div>
  );
}

function MeadowScene({ tier, night }: { tier: string; night: boolean }) {
  return (
    <>
      {/* grass blades */}
      {Array.from({ length: 8 }).map((_, i) => (
        <div key={i} className="absolute bottom-0" style={{ left: `${i * 12 + 2}%` }}>
          <div className="w-1 h-3 bg-green-600/60 rounded-full" />
        </div>
      ))}
      {tier === "saplings" && <Tree x={15} scale={0.5} night={night} />}
      {(tier === "trees" || tier === "castle" || tier === "kingdom") && (
        <>
          <Tree x={12} scale={0.8} night={night} />
          <Tree x={85} scale={0.9} night={night} />
        </>
      )}
      {(tier === "castle" || tier === "kingdom") && <Castle x={50} night={night} />}
      {tier === "kingdom" && (
        <>
          <Castle x={20} night={night} />
          <Castle x={78} night={night} />
        </>
      )}
    </>
  );
}

function ForestScene({ tier, night }: { tier: string; night: boolean }) {
  return (
    <>
      <Tree x={5} scale={1.1} night={night} />
      <Tree x={22} scale={1} night={night} />
      <Tree x={78} scale={1.1} night={night} />
      <Tree x={92} scale={1} night={night} />
      {tier !== "grass" && tier !== "saplings" && <Castle x={50} night={night} />}
    </>
  );
}

function MountainScene({ tier, night }: { tier: string; night: boolean }) {
  return (
    <>
      <svg className="absolute bottom-0 left-0" width="100%" height="100%" viewBox="0 0 400 150" preserveAspectRatio="none">
        <polygon points="0,150 80,30 160,150" fill={night ? "#1e293b" : "#94a3b8"} />
        <polygon points="60,150 160,50 260,150" fill={night ? "#334155" : "#cbd5e1"} />
        <polygon points="200,150 300,20 400,150" fill={night ? "#1e293b" : "#94a3b8"} />
        <polygon points="150,60 160,50 170,60 165,55" fill="white" opacity={night ? 0.4 : 1} />
        <polygon points="290,32 300,20 310,32 305,27" fill="white" opacity={night ? 0.4 : 1} />
      </svg>
      {tier !== "grass" && tier !== "saplings" && <Castle x={50} night={night} />}
    </>
  );
}

function VolcanicScene({ tier, night }: { tier: string; night: boolean }) {
  return (
    <>
      <svg className="absolute bottom-0 left-0" width="100%" height="100%" viewBox="0 0 400 150" preserveAspectRatio="none">
        <polygon points="100,150 180,40 260,150" fill={night ? "#450a0a" : "#7c2d12"} />
        <polygon points="160,70 180,40 200,70" fill="#dc2626" />
        <ellipse cx="180" cy="55" rx="14" ry="6" fill="#f97316" className="streak-glow-pulse" />
      </svg>
      {/* lava glow */}
      <div className="absolute bottom-10 left-1/2 -translate-x-1/2 streak-glow-pulse">
        <div className="w-24 h-3 bg-orange-500 rounded-full blur-md opacity-70" />
      </div>
      {tier !== "grass" && <Castle x={75} night={night} />}
    </>
  );
}

function SkyScene({ tier, night }: { tier: string; night: boolean }) {
  return (
    <>
      {/* floating clouds as ground */}
      {Array.from({ length: 5 }).map((_, i) => (
        <div key={i} className="absolute bottom-0" style={{ left: `${i * 22}%`, bottom: `${5 + (i % 3) * 8}%` }}>
          <Cloud />
        </div>
      ))}
      {tier !== "grass" && <Castle x={50} night={night} />}
    </>
  );
}

function CrystalScene({ tier, night }: { tier: string; night: boolean }) {
  return (
    <>
      {Array.from({ length: 6 }).map((_, i) => (
        <div key={i} className="absolute bottom-0" style={{ left: `${10 + i * 16}%` }}>
          <svg width="40" height="80" viewBox="0 0 40 80">
            <polygon points="20,5 35,40 20,75 5,40" fill={["#a855f7", "#ec4899", "#06b6d4", "#10b981", "#f59e0b", "#ef4444"][i % 6]} opacity={night ? 0.6 : 0.85} />
            <polygon points="20,5 35,40 20,40" fill="white" opacity="0.3" />
          </svg>
        </div>
      ))}
      {tier !== "grass" && <Castle x={50} night={night} />}
    </>
  );
}

function OceanScene({ tier, night }: { tier: string; night: boolean }) {
  return (
    <>
      {/* waves */}
      <svg className="absolute bottom-0 left-0" width="100%" height="100%" viewBox="0 0 400 150" preserveAspectRatio="none">
        <path d="M0,100 Q100,80 200,100 T400,100 L400,150 L0,150 Z" fill={night ? "#1e3a8a" : "#0ea5e9"} opacity="0.6" />
        <path d="M0,115 Q100,95 200,115 T400,115 L400,150 L0,150 Z" fill={night ? "#172554" : "#0284c7"} opacity="0.8" />
      </svg>
      <div className="absolute bottom-2 left-10 text-3xl">🌴</div>
      <div className="absolute bottom-2 right-10 text-3xl">🌴</div>
      {tier !== "grass" && <Castle x={50} night={night} />}
    </>
  );
}
