"use client";
// ===== STREAK — Mini Game: Tangkap Apel =====
import React, { useState, useEffect, useRef, useCallback } from "react";
import type { GameState } from "@/lib/game/types";

interface Props {
  state: GameState;
  onClose: () => void;
  onReward: (score: number) => void;
}

interface FallingItem {
  id: number;
  x: number;
  y: number;
  type: "apple" | "meat" | "gem" | "bomb";
  speed: number;
}

export default function MiniGame({ state, onClose, onReward }: Props) {
  const [phase, setPhase] = useState<"intro" | "playing" | "done">("intro");
  const [score, setScore] = useState(0);
  const [timeLeft, setTimeLeft] = useState(30);
  const [basketX, setBasketX] = useState(50);
  const [items, setItems] = useState<FallingItem[]>([]);
  const [missed, setMissed] = useState(0);
  const itemIdRef = useRef(0);
  const gameAreaRef = useRef<HTMLDivElement>(null);

  const start = () => {
    setScore(0);
    setMissed(0);
    setTimeLeft(30);
    setItems([]);
    setPhase("playing");
  };

  // spawn items
  useEffect(() => {
    if (phase !== "playing") return;
    const spawn = setInterval(() => {
      const r = Math.random();
      let type: FallingItem["type"] = "apple";
      if (r < 0.1) type = "gem";
      else if (r < 0.25) type = "meat";
      else if (r < 0.4) type = "bomb";
      const newItem: FallingItem = {
        id: ++itemIdRef.current,
        x: 5 + Math.random() * 85,
        y: 0,
        type,
        speed: 0.6 + Math.random() * 0.7 + (30 - timeLeft) * 0.02,
      };
      setItems((prev) => [...prev, newItem]);
    }, 700);
    return () => clearInterval(spawn);
  }, [phase, timeLeft]);

  // move items + collision
  useEffect(() => {
    if (phase !== "playing") return;
    const move = setInterval(() => {
      setItems((prev) => {
        const next: FallingItem[] = [];
        for (const it of prev) {
          const ny = it.y + it.speed;
          // collision with basket (basket at ~y 88, x basketX±10)
          if (ny >= 85 && ny <= 95 && Math.abs(it.x - basketX) < 12) {
            // caught
            if (it.type === "apple") setScore((s) => s + 1);
            else if (it.type === "meat") setScore((s) => s + 3);
            else if (it.type === "gem") setScore((s) => s + 5);
            else if (it.type === "bomb") setScore((s) => Math.max(0, s - 2));
            continue;
          }
          if (ny > 100) {
            if (it.type !== "bomb") setMissed((m) => m + 1);
            continue;
          }
          next.push({ ...it, y: ny });
        }
        return next;
      });
    }, 40);
    return () => clearInterval(move);
  }, [phase, basketX]);

  // timer
  useEffect(() => {
    if (phase !== "playing") return;
    const t = setInterval(() => {
      setTimeLeft((tl) => {
        if (tl <= 1) {
          setPhase("done");
          return 0;
        }
        return tl - 1;
      });
    }, 1000);
    return () => clearInterval(t);
  }, [phase]);

  // game over -> reward
  useEffect(() => {
    if (phase === "done") {
      onReward(score);
    }
     
  }, [phase]);

  // controls
  const moveBasket = useCallback((clientX: number) => {
    if (!gameAreaRef.current) return;
    const rect = gameAreaRef.current.getBoundingClientRect();
    const pct = ((clientX - rect.left) / rect.width) * 100;
    setBasketX(Math.max(5, Math.min(95, pct)));
  }, []);

  const handleKey = useCallback((e: KeyboardEvent) => {
    if (e.key === "ArrowLeft") setBasketX((x) => Math.max(5, x - 8));
    if (e.key === "ArrowRight") setBasketX((x) => Math.min(95, x + 8));
  }, []);

  useEffect(() => {
    if (phase !== "playing") return;
    window.addEventListener("keydown", handleKey);
    return () => window.removeEventListener("keydown", handleKey);
  }, [phase, handleKey]);

  const itemEmoji = { apple: "🍎", meat: "🍖", gem: "💎", bomb: "💣" };

  return (
    <div className="fixed inset-0 z-40 bg-black/60 flex items-center justify-center p-2" onClick={onClose}>
      <div className="bg-gradient-to-b from-sky-300 to-green-300 rounded-2xl overflow-hidden streak-pop w-full max-w-md" onClick={(e) => e.stopPropagation()}>
        {/* Header */}
        <div className="flex items-center justify-between p-2.5 bg-white/80 backdrop-blur">
          <h2 className="font-black text-base flex items-center gap-1">🎮 Tangkap Apel</h2>
          <button onClick={onClose} className="w-7 h-7 rounded-full bg-slate-200 hover:bg-slate-300 flex items-center justify-center font-bold text-sm">✕</button>
        </div>

        {phase === "intro" && (
          <div className="p-6 text-center">
            <div className="text-6xl mb-3 streak-bounce inline-block">🍎</div>
            <h3 className="font-black text-lg text-slate-800 mb-1">Tangkap Apel Jatuh!</h3>
            <p className="text-sm text-slate-600 mb-4">Gerakkan keranjang nagamu untuk menangkap apel, daging, dan permata. Hindari bom!</p>
            <div className="grid grid-cols-4 gap-2 mb-4 text-center">
              <div><div className="text-2xl">🍎</div><div className="text-[10px] font-bold text-slate-600">+1</div></div>
              <div><div className="text-2xl">🍖</div><div className="text-[10px] font-bold text-slate-600">+3</div></div>
              <div><div className="text-2xl">💎</div><div className="text-[10px] font-bold text-slate-600">+5</div></div>
              <div><div className="text-2xl">💣</div><div className="text-[10px] font-bold text-red-600">-2</div></div>
            </div>
            <button onClick={start} className="w-full py-3 rounded-xl bg-gradient-to-r from-green-500 to-emerald-600 text-white font-bold hover:opacity-90 active:scale-95 transition">
              ▶️ Mulai (30 detik)
            </button>
          </div>
        )}

        {phase === "playing" && (
          <div className="p-2">
            <div className="flex items-center justify-between mb-1.5 text-sm font-bold">
              <span className="bg-white/80 px-2 py-0.5 rounded-full">⏱ {timeLeft}s</span>
              <span className="bg-white/80 px-2 py-0.5 rounded-full">🍎 {score}</span>
              <span className="bg-white/80 px-2 py-0.5 rounded-full text-red-500">❌ {missed}/5</span>
            </div>
            <div
              ref={gameAreaRef}
              className="relative h-80 bg-gradient-to-b from-sky-200 to-green-200 rounded-xl overflow-hidden cursor-pointer touch-none"
              onMouseMove={(e) => moveBasket(e.clientX)}
              onTouchMove={(e) => e.touches[0] && moveBasket(e.touches[0].clientX)}
            >
              {items.map((it) => (
                <div
                  key={it.id}
                  className="absolute text-2xl select-none"
                  style={{ left: `${it.x}%`, top: `${it.y}%`, transform: "translateX(-50%)" }}
                >
                  {itemEmoji[it.type]}
                </div>
              ))}
              {/* Basket (dragon) */}
              <div
                className="absolute bottom-1 transition-none"
                style={{ left: `${basketX}%`, transform: "translateX(-50%)" }}
              >
                <div className="text-4xl">🧺</div>
              </div>
              {missed >= 5 && (
                <div className="absolute inset-0 flex items-center justify-center bg-black/40 text-white font-black text-xl">
                  Terlalu banyak terlewat!
                </div>
              )}
            </div>
            <p className="text-center text-xs text-slate-600 mt-1.5">Geser mouse / sentuh layar / ← → untuk gerak</p>
          </div>
        )}

        {phase === "done" && (
          <div className="p-6 text-center">
            <div className="text-5xl mb-2">{score >= 20 ? "🏆" : score >= 10 ? "🎉" : "😅"}</div>
            <h3 className="font-black text-xl text-slate-800">Skor: {score}</h3>
            <p className="text-sm text-slate-600 mt-1">
              {score >= 20 ? "Luar biasa!" : score >= 10 ? "Bagus!" : "Lumayan, coba lagi!"}
            </p>
            <p className="text-xs text-slate-500 mt-1">Hadiah otomatis dikirim ke inventaris.</p>
            <div className="flex gap-2 mt-4">
              <button onClick={onClose} className="flex-1 py-2.5 rounded-xl bg-slate-200 text-slate-700 font-bold hover:bg-slate-300 active:scale-95 transition">Tutup</button>
              <button onClick={start} className="flex-1 py-2.5 rounded-xl bg-gradient-to-r from-green-500 to-emerald-600 text-white font-bold hover:opacity-90 active:scale-95 transition">Main Lagi</button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
