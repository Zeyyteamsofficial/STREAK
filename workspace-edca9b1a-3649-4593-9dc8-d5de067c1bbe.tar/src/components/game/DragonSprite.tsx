"use client";
// ===== STREAK — Parametric SVG Dragon Sprite =====
import React from "react";
import type { DragonStage, MoodType, MutationType } from "@/lib/game/types";
import { SKINS, MUTATIONS } from "@/lib/game/data";

interface Props {
  stage: DragonStage;
  mood: MoodType;
  mutation: MutationType;
  skin: string;
  sleeping?: boolean;
  sick?: boolean;
  dead?: boolean;
  accessory?: string | null;
  size?: number;
  animate?: boolean;
}

function getColors(skinId: string, mutation: MutationType) {
  const skin = SKINS.find((s) => s.id === skinId) || SKINS[0];
  const mut = MUTATIONS.find((m) => m.id === mutation) || MUTATIONS[0];
  // mutation overrides skin colors partially
  if (mutation !== "none") {
    return { body: mut.color, belly: "#fff7ed", spike: mut.accent, glow: mut.glow, isRainbow: false };
  }
  return { body: skin.body, belly: skin.belly, spike: skin.spike, glow: "transparent", isRainbow: skin.body === "rainbow" };
}

export default function DragonSprite({
  stage,
  mood,
  mutation,
  skin,
  sleeping = false,
  sick = false,
  dead = false,
  accessory = null,
  size = 260,
  animate = true,
}: Props) {
  const colors = getColors(skin, mutation);
  const isEgg = stage === 0;
  const scale = [0.7, 0.85, 1.0, 1.15, 1.3, 1.45, 1.6, 1.8][stage];
  const hasWings = stage >= 2;
  const bigWings = stage >= 4;
  const hasHorns = stage >= 1;
  const bigHorns = stage >= 3;

  // Mood-driven facial features
  const eyeY = 84;
  const eyeOffset = 22;
  let leftEye = <circle cx={130 - eyeOffset} cy={eyeY} r="7" fill="#1e293b" />;
  let rightEye = <circle cx={130 + eyeOffset} cy={eyeY} r="7" fill="#1e293b" />;
  let mouth = <path d="M 118 104 Q 130 112 142 104" stroke="#1e293b" strokeWidth="2.5" fill="none" strokeLinecap="round" />;
  let cheekColor = "#fb7185";
  let extra: React.ReactNode = null;

  if (dead) {
    leftEye = (
      <g>
        <line x1={130 - eyeOffset - 5} y1={eyeY - 5} x2={130 - eyeOffset + 5} y2={eyeY + 5} stroke="#1e293b" strokeWidth="2.5" strokeLinecap="round" />
        <line x1={130 - eyeOffset + 5} y1={eyeY - 5} x2={130 - eyeOffset - 5} y2={eyeY + 5} stroke="#1e293b" strokeWidth="2.5" strokeLinecap="round" />
      </g>
    );
    rightEye = (
      <g>
        <line x1={130 + eyeOffset - 5} y1={eyeY - 5} x2={130 + eyeOffset + 5} y2={eyeY + 5} stroke="#1e293b" strokeWidth="2.5" strokeLinecap="round" />
        <line x1={130 + eyeOffset + 5} y1={eyeY - 5} x2={130 + eyeOffset - 5} y2={eyeY + 5} stroke="#1e293b" strokeWidth="2.5" strokeLinecap="round" />
      </g>
    );
    mouth = <path d="M 118 110 Q 130 104 142 110" stroke="#1e293b" strokeWidth="2.5" fill="none" strokeLinecap="round" />;
  } else if (sleeping) {
    leftEye = <path d={`M ${130 - eyeOffset - 6} ${eyeY} Q ${130 - eyeOffset} ${eyeY - 5} ${130 - eyeOffset + 6} ${eyeY}`} stroke="#1e293b" strokeWidth="2.5" fill="none" strokeLinecap="round" />;
    rightEye = <path d={`M ${130 + eyeOffset - 6} ${eyeY} Q ${130 + eyeOffset} ${eyeY - 5} ${130 + eyeOffset + 6} ${eyeY}`} stroke="#1e293b" strokeWidth="2.5" fill="none" strokeLinecap="round" />;
    mouth = <path d="M 122 106 Q 130 110 138 106" stroke="#1e293b" strokeWidth="2" fill="none" strokeLinecap="round" />;
    extra = (
      <g className={animate ? "streak-zzz" : ""}>
        <text x="170" y="55" fontSize="16" fill="#64748b" fontWeight="bold">z</text>
        <text x="180" y="42" fontSize="20" fill="#64748b" fontWeight="bold">Z</text>
        <text x="192" y="28" fontSize="24" fill="#64748b" fontWeight="bold">Z</text>
      </g>
    );
  } else if (sick || mood === "sick") {
    leftEye = <g><circle cx={130 - eyeOffset} cy={eyeY} r="6" fill="none" stroke="#1e293b" strokeWidth="2" /><circle cx={130 - eyeOffset} cy={eyeY} r="2" fill="#1e293b" /></g>;
    rightEye = <g><circle cx={130 + eyeOffset} cy={eyeY} r="6" fill="none" stroke="#1e293b" strokeWidth="2" /><circle cx={130 + eyeOffset} cy={eyeY} r="2" fill="#1e293b" /></g>;
    mouth = <path d="M 120 112 Q 130 104 140 112" stroke="#1e293b" strokeWidth="2.5" fill="none" strokeLinecap="round" />;
    cheekColor = "#84cc16";
    extra = (
      <g>
        <circle cx={130 - eyeOffset} cy={eyeY + 14} r="5" fill="#84cc16" opacity="0.5" />
        <circle cx={130 + eyeOffset} cy={eyeY + 14} r="5" fill="#84cc16" opacity="0.5" />
        <text x="180" y="60" fontSize="14">🤢</text>
      </g>
    );
  } else if (mood === "happy") {
    leftEye = <path d={`M ${130 - eyeOffset - 6} ${eyeY + 2} Q ${130 - eyeOffset} ${eyeY - 6} ${130 - eyeOffset + 6} ${eyeY + 2}`} stroke="#1e293b" strokeWidth="2.5" fill="none" strokeLinecap="round" />;
    rightEye = <path d={`M ${130 + eyeOffset - 6} ${eyeY + 2} Q ${130 + eyeOffset} ${eyeY - 6} ${130 + eyeOffset + 6} ${eyeY + 2}`} stroke="#1e293b" strokeWidth="2.5" fill="none" strokeLinecap="round" />;
    mouth = <path d="M 114 102 Q 130 118 146 102" stroke="#1e293b" strokeWidth="2.5" fill="#1e293b" strokeLinecap="round" />;
  } else if (mood === "angry") {
    leftEye = (
      <g>
        <line x1={130 - eyeOffset - 7} y1={eyeY - 6} x2={130 - eyeOffset + 4} y2={eyeY - 2} stroke="#1e293b" strokeWidth="2" strokeLinecap="round" />
        <circle cx={130 - eyeOffset} cy={eyeY + 2} r="5" fill="#dc2626" />
        <circle cx={130 - eyeOffset} cy={eyeY + 2} r="2" fill="#1e293b" />
      </g>
    );
    rightEye = (
      <g>
        <line x1={130 + eyeOffset + 7} y1={eyeY - 6} x2={130 + eyeOffset - 4} y2={eyeY - 2} stroke="#1e293b" strokeWidth="2" strokeLinecap="round" />
        <circle cx={130 + eyeOffset} cy={eyeY + 2} r="5" fill="#dc2626" />
        <circle cx={130 + eyeOffset} cy={eyeY + 2} r="2" fill="#1e293b" />
      </g>
    );
    mouth = <path d="M 118 112 Q 130 104 142 112" stroke="#1e293b" strokeWidth="2.5" fill="none" strokeLinecap="round" />;
    extra = <text x="160" y="55" fontSize="16">💢</text>;
  } else if (mood === "sad") {
    leftEye = <g><circle cx={130 - eyeOffset} cy={eyeY} r="6" fill="#1e293b" /><circle cx={130 - eyeOffset - 1} cy={eyeY - 1} r="2" fill="#fff" /></g>;
    rightEye = <g><circle cx={130 + eyeOffset} cy={eyeY} r="6" fill="#1e293b" /><circle cx={130 + eyeOffset - 1} cy={eyeY - 1} r="2" fill="#fff" /></g>;
    mouth = <path d="M 120 112 Q 130 104 140 112" stroke="#1e293b" strokeWidth="2.5" fill="none" strokeLinecap="round" />;
    extra = (
      <g>
        <path d={`M ${130 - eyeOffset} ${eyeY + 6} q -2 6 0 8`} stroke="#38bdf8" strokeWidth="2" fill="#38bdf8" strokeLinecap="round" />
        <path d={`M ${130 + eyeOffset} ${eyeY + 6} q 2 6 0 8`} stroke="#38bdf8" strokeWidth="2" fill="#38bdf8" strokeLinecap="round" />
      </g>
    );
  } else if (mood === "anxious") {
    leftEye = <g><circle cx={130 - eyeOffset} cy={eyeY} r="7" fill="none" stroke="#1e293b" strokeWidth="2" /><circle cx={130 - eyeOffset} cy={eyeY} r="2.5" fill="#1e293b" /></g>;
    rightEye = <g><circle cx={130 + eyeOffset} cy={eyeY} r="7" fill="none" stroke="#1e293b" strokeWidth="2" /><circle cx={130 + eyeOffset} cy={eyeY} r="2.5" fill="#1e293b" /></g>;
    mouth = <path d="M 122 110 L 126 106 L 130 110 L 134 106 L 138 110" stroke="#1e293b" strokeWidth="2" fill="none" strokeLinecap="round" strokeLinejoin="round" />;
    extra = <text x="160" y="55" fontSize="16">💧</text>;
  } else if (mood === "hungry") {
    leftEye = <g><circle cx={130 - eyeOffset} cy={eyeY} r="7" fill="#1e293b" /><circle cx={130 - eyeOffset + 2} cy={eyeY - 1} r="2" fill="#fff" /></g>;
    rightEye = <g><circle cx={130 + eyeOffset} cy={eyeY} r="7" fill="#1e293b" /><circle cx={130 + eyeOffset + 2} cy={eyeY - 1} r="2" fill="#fff" /></g>;
    mouth = <path d="M 114 108 Q 130 122 146 108" stroke="#1e293b" strokeWidth="2.5" fill="#7f1d1d" strokeLinecap="round" />;
    extra = <text x="165" y="58" fontSize="18">🍴</text>;
  }

  // Body fill (rainbow gradient if rainbow skin)
  const bodyId = `bodyGrad_${mutation}_${skin}`;
  const bellyId = `bellyGrad_${skin}`;
  const rainbowId = `rainbowGrad_${skin}`;

  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 260 260"
      className={animate ? "streak-dragon-bob" : ""}
      style={{ filter: mutation !== "none" ? `drop-shadow(0 0 12px ${colors.glow})` : "drop-shadow(0 4px 8px rgba(0,0,0,0.15))" }}
    >
      <defs>
        <radialGradient id={bodyId} cx="50%" cy="40%" r="60%">
          <stop offset="0%" stopColor={colors.body} stopOpacity="1" />
          <stop offset="100%" stopColor={colors.spike} stopOpacity="1" />
        </radialGradient>
        <linearGradient id={bellyId} x1="0" y1="0" x2="0" y2="1">
          <stop offset="0%" stopColor={colors.belly} />
          <stop offset="100%" stopColor={colors.body} stopOpacity="0.6" />
        </linearGradient>
        <linearGradient id={rainbowId} x1="0" y1="0" x2="1" y2="1">
          <stop offset="0%" stopColor="#ef4444" />
          <stop offset="20%" stopColor="#f97316" />
          <stop offset="40%" stopColor="#eab308" />
          <stop offset="60%" stopColor="#22c55e" />
          <stop offset="80%" stopColor="#38bdf8" />
          <stop offset="100%" stopColor="#a855f7" />
        </linearGradient>
      </defs>

      <g transform={`translate(130 130) scale(${scale}) translate(-130 -130)`}>
        {isEgg ? (
          // ===== EGG =====
          <g className={animate ? "streak-egg-wobble" : ""}>
            <ellipse cx="130" cy="150" rx="55" ry="68" fill={`url(#${colors.isRainbow ? rainbowId : bodyId})`} stroke={colors.spike} strokeWidth="2" />
            {/* egg spots */}
            <ellipse cx="110" cy="120" rx="8" ry="6" fill={colors.spike} opacity="0.4" />
            <ellipse cx="145" cy="140" rx="10" ry="7" fill={colors.spike} opacity="0.4" />
            <ellipse cx="120" cy="170" rx="7" ry="5" fill={colors.spike} opacity="0.4" />
            <ellipse cx="150" cy="180" rx="9" ry="6" fill={colors.spike} opacity="0.4" />
            {/* shine */}
            <ellipse cx="110" cy="115" rx="10" ry="16" fill="#fff" opacity="0.35" transform="rotate(-20 110 115)" />
            {/* crack appears near hatching */}
            {stage === 0 && (
              <path d="M 115 100 L 122 112 L 116 120 L 128 130" stroke="#1e293b" strokeWidth="1.5" fill="none" opacity="0.3" strokeLinecap="round" />
            )}
          </g>
        ) : (
          // ===== DRAGON BODY =====
          <g>
            {/* Tail */}
            <path d={`M ${80} ${185} Q ${60} ${175} ${55} ${155} Q ${52} ${145} ${62} ${148} Q ${72} ${152} ${78} ${168} Z`} fill={`url(#${colors.isRainbow ? rainbowId : bodyId})`} stroke={colors.spike} strokeWidth="1.5" />
            {/* spike on tail */}
            {stage >= 2 && <path d="M 56 150 L 50 140 L 60 148 Z" fill={colors.spike} />}

            {/* Wings */}
            {hasWings && (
              <g className={animate ? "streak-wing-flap" : ""}>
                <path d={`M 95 120 Q ${bigWings ? "55 80" : "70 95"} ${bigWings ? "40 130" : "60 140"} Q ${bigWings ? "70 150" : "80 150"} 95 140 Z`} fill={colors.body} stroke={colors.spike} strokeWidth="1.5" opacity="0.92" />
                <path d={`M 165 120 Q ${bigWings ? "205 80" : "190 95"} ${bigWings ? "220 130" : "200 140"} Q ${bigWings ? "190 150" : "180 150"} 165 140 Z`} fill={colors.body} stroke={colors.spike} strokeWidth="1.5" opacity="0.92" />
                {/* wing bones */}
                <path d={`M 95 120 Q 75 110 60 125`} stroke={colors.spike} strokeWidth="1" fill="none" opacity="0.6" />
                <path d={`M 165 120 Q 185 110 200 125`} stroke={colors.spike} strokeWidth="1" fill="none" opacity="0.6" />
              </g>
            )}

            {/* Body */}
            <ellipse cx="130" cy="155" rx="55" ry="50" fill={`url(#${colors.isRainbow ? rainbowId : bodyId})`} stroke={colors.spike} strokeWidth="2" />
            {/* Belly */}
            <ellipse cx="130" cy="165" rx="36" ry="38" fill={`url(#${bellyId})`} opacity="0.9" />
            {/* belly lines */}
            <path d="M 105 155 Q 130 160 155 155" stroke={colors.spike} strokeWidth="1" fill="none" opacity="0.3" />
            <path d="M 108 170 Q 130 175 152 170" stroke={colors.spike} strokeWidth="1" fill="none" opacity="0.3" />

            {/* Legs */}
            <ellipse cx="108" cy="200" rx="14" ry="10" fill={colors.body} stroke={colors.spike} strokeWidth="1.5" />
            <ellipse cx="152" cy="200" rx="14" ry="10" fill={colors.body} stroke={colors.spike} strokeWidth="1.5" />
            {/* claws */}
            <path d="M 100 205 L 98 212 M 108 207 L 108 214 M 116 205 L 118 212" stroke={colors.spike} strokeWidth="1.5" strokeLinecap="round" />
            <path d="M 144 205 L 142 212 M 152 207 L 152 214 M 160 205 L 162 212" stroke={colors.spike} strokeWidth="1.5" strokeLinecap="round" />

            {/* Spikes on back */}
            {stage >= 1 && (
              <g>
                <path d={`M 90 ${bigHorns ? 140 : 150} L 85 ${bigHorns ? 125 : 135} L 95 ${bigHorns ? 140 : 150} Z`} fill={colors.spike} />
                <path d={`M 110 ${bigHorns ? 125 : 138} L 105 ${bigHorns ? 108 : 122} L 115 ${bigHorns ? 125 : 138} Z`} fill={colors.spike} />
                <path d={`M 130 ${bigHorns ? 120 : 135} L 125 ${bigHorns ? 102 : 118} L 135 ${bigHorns ? 120 : 135} Z`} fill={colors.spike} />
              </g>
            )}

            {/* Head */}
            <ellipse cx="130" cy="95" rx="48" ry="42" fill={`url(#${colors.isRainbow ? rainbowId : bodyId})`} stroke={colors.spike} strokeWidth="2" />
            {/* Head belly/face */}
            <ellipse cx="130" cy="108" rx="34" ry="28" fill={`url(#${bellyId})`} opacity="0.85" />

            {/* Horns */}
            {hasHorns && (
              <g>
                <path d={`M 108 62 Q ${bigHorns ? "95 40" : "100 52"} ${bigHorns ? "90 30" : "98 48"} L 108 56 Z`} fill={colors.spike} />
                <path d={`M 152 62 Q ${bigHorns ? "165 40" : "160 52"} ${bigHorns ? "170 30" : "162 48"} L 152 56 Z`} fill={colors.spike} />
              </g>
            )}

            {/* Cheeks */}
            <circle cx={130 - eyeOffset - 8} cy={eyeY + 8} r="6" fill={cheekColor} opacity="0.5" />
            <circle cx={130 + eyeOffset + 8} cy={eyeY + 8} r="6" fill={cheekColor} opacity="0.5" />

            {/* Eyes */}
            {leftEye}
            {rightEye}

            {/* Nostrils */}
            <circle cx="124" cy="92" r="1.5" fill="#1e293b" opacity="0.5" />
            <circle cx="136" cy="92" r="1.5" fill="#1e293b" opacity="0.5" />

            {/* Mouth */}
            {mouth}

            {/* Extra mood elements */}
            {extra}

            {/* Mutation aura particles */}
            {mutation === "fire" && !dead && (
              <g className={animate ? "streak-fire" : ""}>
                <circle cx="90" cy="100" r="4" fill="#f97316" opacity="0.7" />
                <circle cx="170" cy="105" r="3" fill="#fbbf24" opacity="0.7" />
                <circle cx="130" cy="55" r="3" fill="#ef4444" opacity="0.6" />
              </g>
            )}
            {mutation === "ice" && !dead && (
              <g>
                <text x="80" y="100" fontSize="14">❄</text>
                <text x="170" y="120" fontSize="12">❄</text>
                <text x="135" y="60" fontSize="10">❄</text>
              </g>
            )}
            {mutation === "lightning" && !dead && (
              <g className={animate ? "streak-flash" : ""}>
                <path d="M 85 90 L 92 100 L 88 102 L 95 115" stroke="#facc15" strokeWidth="2" fill="none" strokeLinecap="round" />
                <path d="M 175 95 L 168 105 L 172 107 L 165 120" stroke="#facc15" strokeWidth="2" fill="none" strokeLinecap="round" />
              </g>
            )}
            {mutation === "nature" && !dead && (
              <g>
                <text x="78" y="115" fontSize="14">🍃</text>
                <text x="170" y="130" fontSize="12">🌿</text>
              </g>
            )}
            {mutation === "shadow" && !dead && (
              <g className={animate ? "streak-shadow" : ""}>
                <circle cx="130" cy="95" r="60" fill="#1e1b4b" opacity="0.15" />
              </g>
            )}

            {/* Accessory */}
            {accessory === "hat_topi" && <text x="115" y="55" fontSize="26">🎩</text>}
            {accessory === "hat_kacamata" && <text x="108" y="88" fontSize="22">🕶️</text>}
            {accessory === "hat_mahkota" && <text x="110" y="58" fontSize="26">👑</text>}
            {accessory === "hat_pedang" && <text x="170" y="160" fontSize="24" transform="rotate(30 175 165)">🗡️</text>}
            {accessory === "hat_pita" && <text x="92" y="62" fontSize="20">🎀</text>}
            {accessory === "hat_topi_pesta" && <text x="112" y="52" fontSize="26">🥳</text>}
            {accessory === "hat_halo" && <text x="110" y="48" fontSize="22">😇</text>}
            {accessory === "hat_tanduk" && <g><text x="96" y="50" fontSize="20">😈</text></g>}
          </g>
        )}
      </g>
    </svg>
  );
}
