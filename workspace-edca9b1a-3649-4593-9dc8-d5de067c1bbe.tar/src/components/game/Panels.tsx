"use client";
// ===== STREAK — Menu Panels =====
import React, { useState } from "react";
import type { GameState } from "@/lib/game/types";
import {
  ITEMS, SKINS, AREAS, ACHIEVEMENTS, STAGES, MUTATIONS,
  STREAK_REWARDS, MISSION_RESET_MS, GAME_VERSION, GAME_MAKER, DAILY_FREE_FOOD,
} from "@/lib/game/data";
import * as engine from "@/lib/game/engine";

// ===== Shared shell =====
function PanelShell({ title, icon, onClose, children, accent = "from-orange-500 to-red-500" }: {
  title: string; icon: string; onClose: () => void; children: React.ReactNode; accent?: string;
}) {
  return (
    <div className="fixed inset-0 z-40 bg-black/50 flex items-end sm:items-center justify-center" onClick={onClose}>
      <div
        className="bg-white w-full sm:max-w-lg sm:rounded-2xl rounded-t-2xl streak-pop max-h-[85vh] flex flex-col"
        onClick={(e) => e.stopPropagation()}
      >
        <div className={`flex items-center gap-2 p-3 sm:rounded-t-2xl bg-gradient-to-r ${accent} text-white`}>
          <span className="text-xl">{icon}</span>
          <h2 className="font-black text-lg flex-1">{title}</h2>
          <button onClick={onClose} className="w-8 h-8 rounded-full bg-white/20 hover:bg-white/30 flex items-center justify-center font-bold">✕</button>
        </div>
        <div className="flex-1 overflow-y-auto p-3 streak-scroll">
          {children}
        </div>
      </div>
    </div>
  );
}

const rarityColors: Record<string, string> = {
  common: "border-slate-300 bg-slate-50 text-slate-600",
  rare: "border-blue-300 bg-blue-50 text-blue-600",
  epic: "border-purple-300 bg-purple-50 text-purple-600",
  legendary: "border-amber-400 bg-amber-50 text-amber-600",
};
const rarityBadge: Record<string, string> = {
  common: "bg-slate-200 text-slate-600",
  rare: "bg-blue-200 text-blue-700",
  epic: "bg-purple-200 text-purple-700",
  legendary: "bg-amber-200 text-amber-700",
};

// ===== Shop Panel =====
export function ShopPanel({ state, onClose, onBuy, onBuySkin }: {
  state: GameState; onClose: () => void; onBuy: (id: string) => void; onBuySkin: (id: string) => void;
}) {
  const [tab, setTab] = useState<"items" | "skins" | "gamepass">("items");
  const ownedSkins = new Set(state.inventory.filter((i) => i.type === "skin").map((i) => i.itemId));
  return (
    <PanelShell title="Toko Naga" icon="🛒" onClose={onClose} accent="from-amber-500 to-orange-500">
      <div className="flex gap-1 mb-3 bg-slate-100 p-1 rounded-xl">
        {([["items", "📦 Item"], ["skins", "🎨 Kulit"], ["gamepass", "⭐ Gamepass"]] as const).map(([k, l]) => (
          <button key={k} onClick={() => setTab(k)} className={`flex-1 py-1.5 rounded-lg text-xs font-bold transition ${tab === k ? "bg-white shadow text-orange-600" : "text-slate-500"}`}>{l}</button>
        ))}
      </div>
      <div className="flex items-center gap-2 mb-3 text-sm">
        <span className="flex items-center gap-1 bg-amber-100 px-2 py-1 rounded-full">🪙 {state.resources.coins}</span>
        <span className="flex items-center gap-1 bg-cyan-100 px-2 py-1 rounded-full">💎 {state.resources.gems}</span>
      </div>

      {tab === "items" && (
        <div className="grid grid-cols-2 gap-2">
          {ITEMS.filter((i) => i.type !== "gamepass").map((item) => (
            <div key={item.id} className={`p-2.5 rounded-xl border-2 ${rarityColors[item.rarity]}`}>
              <div className="flex items-start gap-2">
                <span className="text-3xl">{item.icon}</span>
                <div className="flex-1 min-w-0">
                  <div className="font-bold text-sm text-slate-800 truncate">{item.name}</div>
                  <span className={`inline-block text-[9px] px-1 rounded-full font-bold ${rarityBadge[item.rarity]}`}>{item.rarity}</span>
                  <p className="text-[11px] text-slate-500 mt-0.5 line-clamp-2">{item.desc}</p>
                </div>
              </div>
              <button
                onClick={() => onBuy(item.id)}
                className={`w-full mt-2 py-1.5 rounded-lg font-bold text-xs ${item.currency === "coins" ? "bg-amber-500 text-white hover:bg-amber-600" : "bg-cyan-500 text-white hover:bg-cyan-600"} active:scale-95 transition`}
              >
                {item.currency === "coins" ? "🪙" : "💎"} {item.price}
              </button>
            </div>
          ))}
        </div>
      )}

      {tab === "skins" && (
        <div className="grid grid-cols-2 gap-2">
          {SKINS.map((skin) => {
            const owned = ownedSkins.has(skin.id) || skin.id === "classic";
            const equipped = state.dragon?.skin === skin.id;
            return (
              <div key={skin.id} className={`p-2.5 rounded-xl border-2 ${rarityColors[skin.rarity]}`}>
                <div className="flex items-center justify-center h-14 rounded-lg" style={{ background: skin.body === "rainbow" ? "linear-gradient(45deg,#ef4444,#f97316,#eab308,#22c55e,#38bdf8,#a855f7)" : `linear-gradient(135deg, ${skin.body}, ${skin.spike})` }}>
                  <span className="text-2xl drop-shadow">🐲</span>
                </div>
                <div className="font-bold text-sm text-slate-800 mt-1.5 truncate">{skin.name}</div>
                <span className={`inline-block text-[9px] px-1 rounded-full font-bold ${rarityBadge[skin.rarity]}`}>{skin.rarity}</span>
                <p className="text-[11px] text-slate-500 mt-0.5 line-clamp-2">{skin.desc}</p>
                {equipped ? (
                  <div className="w-full mt-2 py-1.5 rounded-lg font-bold text-xs bg-green-100 text-green-700 text-center">✓ Dipakai</div>
                ) : owned ? (
                  <div className="w-full mt-2 py-1.5 rounded-lg font-bold text-xs bg-slate-100 text-slate-500 text-center">Dimiliki</div>
                ) : (
                  <button
                    onClick={() => onBuySkin(skin.id)}
                    className="w-full mt-2 py-1.5 rounded-lg font-bold text-xs bg-cyan-500 text-white hover:bg-cyan-600 active:scale-95 transition"
                  >
                    💎 {skin.price}
                  </button>
                )}
              </div>
            );
          })}
        </div>
      )}

      {tab === "gamepass" && (
        <div className="space-y-2">
          {ITEMS.filter((i) => i.type === "gamepass").map((item) => {
            const owned = state.gamepass.owned.includes(item.id);
            return (
              <div key={item.id} className={`p-3 rounded-xl border-2 ${rarityColors[item.rarity]} flex items-center gap-3`}>
                <span className="text-4xl">{item.icon}</span>
                <div className="flex-1">
                  <div className="font-bold text-slate-800">{item.name}</div>
                  <span className={`inline-block text-[9px] px-1 rounded-full font-bold ${rarityBadge[item.rarity]}`}>{item.rarity}</span>
                  <p className="text-xs text-slate-500 mt-0.5">{item.desc}</p>
                  {item.effect === "doublegrowth" && owned && state.gamepass.doubleGrowthUntil > Date.now() && (
                    <p className="text-[10px] text-green-600 mt-0.5">⏱ Aktif sampai {new Date(state.gamepass.doubleGrowthUntil).toLocaleDateString("id-ID")}</p>
                  )}
                </div>
                {owned ? (
                  <span className="text-xs font-bold text-green-600">✓ Aktif</span>
                ) : (
                  <button
                    onClick={() => onBuy(item.id)}
                    className="py-2 px-3 rounded-lg font-bold text-xs bg-cyan-500 text-white hover:bg-cyan-600 active:scale-95 transition"
                  >
                    💎 {item.price}
                  </button>
                )}
              </div>
            );
          })}
        </div>
      )}
    </PanelShell>
  );
}

// ===== Inventory Panel =====
export function InventoryPanel({ state, onClose, onUse, onEquip, onEquipSkin }: {
  state: GameState; onClose: () => void; onUse: (id: string) => void; onEquip: (id: string) => void; onEquipSkin: (id: string) => void;
}) {
  const [tab, setTab] = useState<"all" | "accessory" | "food" | "medicine" | "skin">("all");
  const items = state.inventory.filter((i) => tab === "all" || i.type === tab);
  return (
    <PanelShell title="Inventaris" icon="🎒" onClose={onClose} accent="from-emerald-500 to-teal-500">
      <div className="flex gap-1 mb-3 bg-slate-100 p-1 rounded-xl overflow-x-auto streak-scroll">
        {([["all", "Semua"], ["accessory", "Aksesori"], ["food", "Makanan"], ["medicine", "Obat"], ["skin", "Kulit"]] as const).map(([k, l]) => (
          <button key={k} onClick={() => setTab(k)} className={`px-3 py-1.5 rounded-lg text-xs font-bold whitespace-nowrap transition ${tab === k ? "bg-white shadow text-emerald-600" : "text-slate-500"}`}>{l}</button>
        ))}
      </div>
      {items.length === 0 ? (
        <div className="text-center py-12 text-slate-400">
          <div className="text-5xl mb-2">📭</div>
          <p className="text-sm">Inventaris kosong</p>
          <p className="text-xs">Beli item di toko atau buka peti hadiah!</p>
        </div>
      ) : (
        <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
          {items.map((item) => (
            <div key={item.id} className={`p-2.5 rounded-xl border-2 ${rarityColors[item.rarity]}`}>
              <div className="flex items-center justify-between">
                <span className="text-3xl">{item.icon}</span>
                {item.qty > 1 && <span className="text-xs font-bold text-slate-500">x{item.qty}</span>}
              </div>
              <div className="font-bold text-xs text-slate-800 mt-1 truncate">{item.name}</div>
              <span className={`inline-block text-[9px] px-1 rounded-full font-bold ${rarityBadge[item.rarity]}`}>{item.rarity}</span>
              <div className="mt-1.5">
                {item.type === "skin" ? (
                  <button
                    onClick={() => onEquipSkin(item.itemId)}
                    className={`w-full py-1.5 rounded-lg font-bold text-[11px] active:scale-95 transition ${state.dragon?.skin === item.itemId ? "bg-green-100 text-green-700" : "bg-emerald-500 text-white hover:bg-emerald-600"}`}
                  >
                    {state.dragon?.skin === item.itemId ? "✓ Dipakai" : "Pasang"}
                  </button>
                ) : item.type === "accessory" ? (
                  <button
                    onClick={() => onEquip(item.itemId)}
                    className={`w-full py-1.5 rounded-lg font-bold text-[11px] active:scale-95 transition ${state.dragon?.accessory === item.itemId ? "bg-green-100 text-green-700" : "bg-emerald-500 text-white hover:bg-emerald-600"}`}
                  >
                    {state.dragon?.accessory === item.itemId ? "✓ Dipakai" : "Pakai"}
                  </button>
                ) : (
                  <button
                    onClick={() => onUse(item.itemId)}
                    className="w-full py-1.5 rounded-lg font-bold text-[11px] bg-emerald-500 text-white hover:bg-emerald-600 active:scale-95 transition"
                  >
                    Gunakan
                  </button>
                )}
              </div>
            </div>
          ))}
        </div>
      )}
    </PanelShell>
  );
}

// ===== Missions Panel =====
export function MissionsPanel({ state, onClose, onClaim, onReroll }: {
  state: GameState; onClose: () => void; onClaim: (id: string) => void; onReroll: () => void;
}) {
  const resetIn = MISSION_RESET_MS - (Date.now() - state.missions.generatedAt);
  return (
    <PanelShell title="Misi Harian" icon="📜" onClose={onClose} accent="from-blue-500 to-indigo-500">
      <div className="flex items-center justify-between mb-3 text-xs text-slate-500">
        <span>🔄 Reset dalam {resetIn > 0 ? formatMs(resetIn) : "sekarang"}</span>
        <button
          onClick={onReroll}
          disabled={state.resources.gems < 5}
          className="flex items-center gap-1 px-2 py-1 rounded-lg bg-cyan-100 text-cyan-700 font-bold hover:bg-cyan-200 disabled:opacity-40 active:scale-95 transition"
        >
          🎲 Reroll (💎5)
        </button>
      </div>
      <div className="space-y-2">
        {state.missions.missions.map((m) => (
          <div key={m.id} className={`p-3 rounded-xl border-2 ${m.done ? "border-green-300 bg-green-50" : "border-slate-200 bg-slate-50"}`}>
            <div className="flex items-center justify-between">
              <span className="font-bold text-sm text-slate-800">{m.desc}</span>
              {m.done && <span className="text-green-600 text-lg">✓</span>}
            </div>
            <div className="mt-1.5 h-2 bg-slate-200 rounded-full overflow-hidden">
              <div className="h-full bg-blue-500 transition-all" style={{ width: `${Math.min(100, (m.progress / m.target) * 100)}%` }} />
            </div>
            <div className="flex items-center justify-between mt-1.5">
              <span className="text-xs text-slate-500">{m.progress}/{m.target}</span>
              <div className="flex items-center gap-1.5">
                <span className="text-xs font-bold text-amber-600">🪙 {m.rewardCoins}</span>
                {m.rewardGems > 0 && <span className="text-xs font-bold text-cyan-600">💎 {m.rewardGems}</span>}
                {m.done && (
                  <button
                    onClick={() => onClaim(m.id)}
                    disabled={m.claimed}
                    className={`ml-1 px-2.5 py-1 rounded-lg text-xs font-bold active:scale-95 transition ${m.claimed ? "bg-slate-200 text-slate-400" : "bg-green-500 text-white hover:bg-green-600"}`}
                  >
                    {m.claimed ? "Diklaim" : "Klaim"}
                  </button>
                )}
              </div>
            </div>
          </div>
        ))}
      </div>
    </PanelShell>
  );
}

// ===== Stats Panel =====
export function StatsPanel({ state, onClose }: { state: GameState; onClose: () => void }) {
  const d = state.dragon!;
  const rows: [string, string | number][] = [
    ["Nama Naga", d.name],
    ["Generasi", d.generation],
    ["Umur", `${engine.dragonAgeDays(d)} hari`],
    ["Tahap", STAGES[d.stage].name],
    ["Mutasi", d.mutation === "none" ? "Normal" : d.mutation],
    ["Bond Level", Math.round(d.bond)],
    ["Streak Saat Ini", `${state.streak.current} hari`],
    ["Rekor Streak", `${state.streak.record} hari`],
    ["Total Makanan", state.stats.totalFood],
    ["Total Klik", state.stats.totalClicks],
    ["Total Elusan", state.stats.totalPets],
    ["Total Bermain", state.stats.totalPlays],
    ["Total Bersih", state.stats.totalCleaned],
    ["Mini Game", state.stats.miniGamesPlayed],
    ["Peti Dibuka", state.stats.chestsOpened],
    ["Koin Earned", state.stats.totalCoinsEarned],
    ["Gem Earned", state.stats.totalGemsEarned],
    ["Hari Aktif", state.stats.daysActive],
    ["Total Naga (Legacy)", state.legacy.totalDragons],
    ["Rekor Umur Tertinggi", `${state.legacy.recordDays} hari`],
    ["Bonus Legacy", `${state.legacy.bonus}%`],
  ];
  return (
    <PanelShell title="Statistik" icon="📈" onClose={onClose} accent="from-violet-500 to-purple-500">
      <div className="space-y-1">
        {rows.map(([k, v]) => (
          <div key={k} className="flex items-center justify-between py-1.5 px-2 rounded-lg hover:bg-slate-50">
            <span className="text-sm text-slate-600">{k}</span>
            <span className="text-sm font-bold text-slate-800">{v}</span>
          </div>
        ))}
      </div>
    </PanelShell>
  );
}

// ===== History Panel (Buku Sejarah Naga) =====
export function HistoryPanel({ state, onClose }: { state: GameState; onClose: () => void }) {
  return (
    <PanelShell title="Buku Sejarah Naga" icon="📚" onClose={onClose} accent="from-stone-600 to-amber-700">
      <p className="text-xs text-slate-500 mb-3">Arsip semua naga yang pernah hidup. Semua kenangan abadi.</p>
      {state.history.length === 0 ? (
        <div className="text-center py-12 text-slate-400">
          <div className="text-5xl mb-2">📖</div>
          <p className="text-sm">Belum ada naga yang tercatat</p>
          <p className="text-xs">Sejarah naga yang mati akan muncul di sini.</p>
        </div>
      ) : (
        <div className="space-y-2">
          {state.history.map((rec, i) => (
            <div key={rec.id} className="p-3 rounded-xl bg-gradient-to-r from-amber-50 to-stone-50 border border-amber-200 flex items-center gap-3">
              <div className="w-10 h-10 rounded-full bg-amber-200 flex items-center justify-center font-black text-amber-800 text-sm">
                #{state.history.length - i}
              </div>
              <div className="flex-1 min-w-0">
                <div className="font-bold text-slate-800 truncate">{rec.name}</div>
                <div className="text-xs text-slate-500">
                  {STAGES[rec.stage].emoji} {STAGES[rec.stage].name} · Gen {rec.generation}
                  {rec.mutation !== "none" && ` · ${rec.mutation}`}
                </div>
                <div className="text-[11px] text-slate-400">Mati karena {rec.cause}</div>
              </div>
              <div className="text-right">
                <div className="font-black text-amber-700">{rec.daysLived}</div>
                <div className="text-[10px] text-slate-500">hari</div>
              </div>
            </div>
          ))}
        </div>
      )}
    </PanelShell>
  );
}

// ===== Areas Panel =====
export function AreasPanel({ state, onClose, onChange }: {
  state: GameState; onClose: () => void; onChange: (id: string) => void;
}) {
  return (
    <PanelShell title="Pilih Area" icon="🗺️" onClose={onClose} accent="from-green-500 to-teal-500">
      <p className="text-xs text-slate-500 mb-3">Buka area baru dengan menjaga streak! Area dibuka berdasarkan rekor streak.</p>
      <div className="grid grid-cols-2 gap-2">
        {AREAS.map((area) => {
          const unlocked = state.areas.unlocked.includes(area.id);
          const current = state.areas.current === area.id;
          return (
            <button
              key={area.id}
              onClick={() => unlocked && onChange(area.id)}
              disabled={!unlocked}
              className={`relative p-3 rounded-xl border-2 text-left transition ${current ? "border-green-400 bg-green-50" : unlocked ? "border-slate-200 bg-white hover:bg-slate-50 active:scale-95" : "border-slate-200 bg-slate-100 opacity-60"}`}
            >
              <div className="text-3xl mb-1">{area.emoji}</div>
              <div className="font-bold text-sm text-slate-800">{area.name}</div>
              <p className="text-[11px] text-slate-500 line-clamp-2">{area.desc}</p>
              {!unlocked && (
                <div className="absolute inset-0 flex flex-col items-center justify-center bg-slate-900/40 rounded-xl text-white">
                  <span className="text-2xl">🔒</span>
                  <span className="text-[10px] font-bold">Streak {area.unlockStreak}</span>
                </div>
              )}
              {current && <div className="absolute top-1 right-1 text-green-600 text-xs font-bold">✓</div>}
            </button>
          );
        })}
      </div>
    </PanelShell>
  );
}

// ===== Achievements Panel =====
export function AchievementsPanel({ state, onClose }: { state: GameState; onClose: () => void }) {
  const unlocked = new Set(state.achievements.unlocked);
  return (
    <PanelShell title="Achievement" icon="🏅" onClose={onClose} accent="from-yellow-500 to-amber-600">
      <p className="text-xs text-slate-500 mb-3">Terbuka {unlocked.size}/{ACHIEVEMENTS.length}</p>
      <div className="grid grid-cols-2 gap-2">
        {ACHIEVEMENTS.map((a) => {
          const got = unlocked.has(a.id);
          return (
            <div key={a.id} className={`p-3 rounded-xl border-2 text-center transition ${got ? "border-amber-400 bg-amber-50" : "border-slate-200 bg-slate-50 opacity-60"}`}>
              <div className={`text-4xl mb-1 ${got ? "" : "grayscale"}`}>{got ? a.icon : "🔒"}</div>
              <div className="font-bold text-xs text-slate-800">{a.name}</div>
              <p className="text-[10px] text-slate-500 mt-0.5">{a.desc}</p>
            </div>
          );
        })}
      </div>
    </PanelShell>
  );
}

// ===== Settings Panel =====
export function SettingsPanel({ state, onClose, onUpdate, onRename, onReset }: {
  state: GameState; onClose: () => void;
  onUpdate: (s: Partial<GameState["settings"]>) => void;
  onRename: (name: string) => void;
  onReset: () => void;
}) {
  const [rename, setRename] = useState(state.dragon?.name || "");
  return (
    <PanelShell title="Pengaturan" icon="⚙️" onClose={onClose} accent="from-slate-600 to-slate-700">
      <div className="space-y-3">
        <div className="p-3 rounded-xl bg-slate-50 border border-slate-200">
          <label className="text-sm font-bold text-slate-700">Ganti Nama Naga</label>
          <div className="flex gap-2 mt-1.5">
            <input
              type="text"
              value={rename}
              onChange={(e) => setRename(e.target.value)}
              maxLength={16}
              className="flex-1 px-3 py-2 rounded-lg border border-slate-200 focus:border-slate-400 outline-none text-sm"
            />
            <button
              onClick={() => onRename(rename)}
              disabled={!rename.trim() || rename.trim() === state.dragon?.name}
              className="px-3 py-2 rounded-lg bg-slate-700 text-white text-sm font-bold hover:bg-slate-800 disabled:opacity-40 active:scale-95 transition"
            >
              Simpan
            </button>
          </div>
        </div>

        <ToggleRow label="🔊 Efek Suara" value={state.settings.sound} onChange={(v) => onUpdate({ sound: v })} />
        <ToggleRow label="🎵 Musik Latar" value={state.settings.music} onChange={(v) => onUpdate({ music: v })} />
        <ToggleRow label="🗣️ Suara Naga (TTS)" value={state.settings.voice} onChange={(v) => onUpdate({ voice: v })} />

        <div className="p-3 rounded-xl bg-slate-50 border border-slate-200 text-xs text-slate-500 space-y-1">
          <div className="flex justify-between"><span>Versi Game</span><span className="font-bold text-slate-700">v{GAME_VERSION}</span></div>
          <div className="flex justify-between"><span>Dibuat oleh</span><span className="font-bold text-slate-700">{GAME_MAKER}</span></div>
          <div className="flex justify-between"><span>Makanan Gratis/Hari</span><span className="font-bold text-slate-700">{DAILY_FREE_FOOD}</span></div>
        </div>

        <button
          onClick={onReset}
          className="w-full py-2.5 rounded-xl bg-red-100 text-red-600 font-bold text-sm hover:bg-red-200 active:scale-95 transition"
        >
          🗑️ Reset Semua Progress
        </button>
      </div>
    </PanelShell>
  );
}

function ToggleRow({ label, value, onChange }: { label: string; value: boolean; onChange: (v: boolean) => void }) {
  return (
    <div className="flex items-center justify-between p-3 rounded-xl bg-slate-50 border border-slate-200">
      <span className="text-sm font-semibold text-slate-700">{label}</span>
      <button
        onClick={() => onChange(!value)}
        className={`w-12 h-7 rounded-full transition relative ${value ? "bg-green-500" : "bg-slate-300"}`}
      >
        <div className={`absolute top-0.5 w-6 h-6 rounded-full bg-white shadow transition-all ${value ? "left-5" : "left-0.5"}`} />
      </button>
    </div>
  );
}

// ===== Growth Panel =====
export function GrowthPanel({ state, onClose }: { state: GameState; onClose: () => void }) {
  const d = state.dragon!;
  return (
    <PanelShell title="Pertumbuhan Naga" icon="🌱" onClose={onClose} accent="from-green-500 to-emerald-600">
      <div className="text-center mb-3">
        <div className="text-5xl mb-1">{STAGES[d.stage].emoji}</div>
        <div className="font-black text-lg text-slate-800">{STAGES[d.stage].name}</div>
        <p className="text-xs text-slate-500">{STAGES[d.stage].desc}</p>
      </div>
      <div className="space-y-2">
        {STAGES.map((s, i) => {
          const done = i < d.stage;
          const current = i === d.stage;
          const locked = i > d.stage;
          return (
            <div key={s.id} className={`flex items-center gap-3 p-2.5 rounded-xl border-2 ${current ? "border-green-400 bg-green-50" : done ? "border-slate-200 bg-slate-50" : "border-slate-200 bg-white opacity-60"}`}>
              <div className={`w-9 h-9 rounded-full flex items-center justify-center text-lg ${done ? "bg-green-200" : current ? "bg-green-300 streak-glow-pulse" : "bg-slate-200"}`}>
                {done ? "✓" : s.emoji}
              </div>
              <div className="flex-1">
                <div className="font-bold text-sm text-slate-800">{s.name}</div>
                <div className="text-[11px] text-slate-500">{s.desc}</div>
              </div>
              {current && (
                <div className="text-right">
                  <div className="text-[10px] text-slate-500">Evolusi dalam</div>
                  <div className="text-xs font-bold text-green-600">{formatMs(engine.msToHatch(d))}</div>
                </div>
              )}
              {locked && <div className="text-[10px] text-slate-400">{s.durationMs >= 86400000 ? `${s.durationMs / 86400000}h` : ""}</div>}
            </div>
          );
        })}
      </div>
      {state.gamepass.doubleGrowthUntil > Date.now() && (
        <div className="mt-3 p-2 rounded-lg bg-cyan-50 text-cyan-700 text-xs font-bold text-center">🚀 2x Pertumbuhan aktif!</div>
      )}
      {state.legacy.bonus > 0 && (
        <div className="mt-2 p-2 rounded-lg bg-amber-50 text-amber-700 text-xs font-bold text-center">🏛️ Bonus Legacy: +{state.legacy.bonus}% kecepatan tumbuh</div>
      )}
    </PanelShell>
  );
}

// ===== Bond Panel =====
export function BondPanel({ state, onClose }: { state: GameState; onClose: () => void }) {
  const d = state.dragon!;
  const bondLevel = Math.floor(d.bond / 20) + 1; // 1-6
  const bondTitle = ["Asing", "Kenal", "Akrab", "Sahabat", "Saudara", "Soulmate"][Math.min(5, bondLevel - 1)];
  return (
    <PanelShell title="Bond Level" icon="❤️" onClose={onClose} accent="from-rose-500 to-red-500">
      <div className="text-center mb-4">
        <div className="text-6xl mb-1">❤️</div>
        <div className="font-black text-2xl text-rose-600">Lv {bondLevel}</div>
        <div className="text-sm text-slate-500">{bondTitle}</div>
      </div>
      <div className="h-3 bg-slate-200 rounded-full overflow-hidden mb-1">
        <div className="h-full bg-gradient-to-r from-rose-400 to-red-500 transition-all" style={{ width: `${d.bond}%` }} />
      </div>
      <div className="text-right text-xs text-slate-500 mb-4">{Math.round(d.bond)}/100</div>
      <div className="space-y-2 text-sm">
        <h3 className="font-bold text-slate-700">Cara menaikkan bond:</h3>
        <div className="flex items-center gap-2 p-2 rounded-lg bg-rose-50">🤚 <span>Elus naga (+4)</span></div>
        <div className="flex items-center gap-2 p-2 rounded-lg bg-rose-50">🎾 <span>Bermain (+6)</span></div>
        <div className="flex items-center gap-2 p-2 rounded-lg bg-rose-50">🍖 <span>Beri makan (+2)</span></div>
        <div className="flex items-center gap-2 p-2 rounded-lg bg-rose-50">👆 <span>Klik naga (+0.3)</span></div>
        <h3 className="font-bold text-slate-700 mt-3">Bonus bond tinggi:</h3>
        <div className="flex items-center gap-2 p-2 rounded-lg bg-green-50 text-green-700">✨ Mood lebih stabil</div>
        <div className="flex items-center gap-2 p-2 rounded-lg bg-green-50 text-green-700">😊 Naga lebih bahagia</div>
        <div className="flex items-center gap-2 p-2 rounded-lg bg-green-50 text-green-700">🎁 Animasi spesial</div>
      </div>
    </PanelShell>
  );
}

// ===== Skin Panel =====
export function SkinPanel({ state, onClose, onEquip, onBuy }: {
  state: GameState; onClose: () => void; onEquip: (id: string) => void; onBuy: (id: string) => void;
}) {
  const ownedSkins = new Set(state.inventory.filter((i) => i.type === "skin").map((i) => i.itemId));
  return (
    <PanelShell title="Kulit Naga" icon="🎨" onClose={onClose} accent="from-pink-500 to-rose-500">
      <div className="grid grid-cols-2 gap-2">
        {SKINS.map((skin) => {
          const owned = ownedSkins.has(skin.id) || skin.id === "classic";
          const equipped = state.dragon?.skin === skin.id;
          return (
            <div key={skin.id} className={`p-2.5 rounded-xl border-2 ${equipped ? "border-pink-400 bg-pink-50" : rarityColors[skin.rarity]}`}>
              <div className="flex items-center justify-center h-16 rounded-lg" style={{ background: skin.body === "rainbow" ? "linear-gradient(45deg,#ef4444,#f97316,#eab308,#22c55e,#38bdf8,#a855f7)" : `linear-gradient(135deg, ${skin.body}, ${skin.spike})` }}>
                <span className="text-3xl drop-shadow-lg">🐲</span>
              </div>
              <div className="font-bold text-sm text-slate-800 mt-1.5 truncate">{skin.name}</div>
              <span className={`inline-block text-[9px] px-1 rounded-full font-bold ${rarityBadge[skin.rarity]}`}>{skin.rarity}</span>
              {equipped ? (
                <div className="w-full mt-2 py-1.5 rounded-lg font-bold text-xs bg-pink-100 text-pink-700 text-center">✓ Dipakai</div>
              ) : owned ? (
                <button onClick={() => onEquip(skin.id)} className="w-full mt-2 py-1.5 rounded-lg font-bold text-xs bg-pink-500 text-white hover:bg-pink-600 active:scale-95 transition">Pasang</button>
              ) : (
                <button onClick={() => onBuy(skin.id)} className="w-full mt-2 py-1.5 rounded-lg font-bold text-xs bg-cyan-500 text-white hover:bg-cyan-600 active:scale-95 transition">💎 {skin.price}</button>
              )}
            </div>
          );
        })}
      </div>
    </PanelShell>
  );
}

// helper
function formatMs(ms: number) {
  if (ms <= 0) return "Siap!";
  const totalSec = Math.floor(ms / 1000);
  const h = Math.floor(totalSec / 3600);
  const m = Math.floor((totalSec % 3600) / 60);
  const s = totalSec % 60;
  if (h > 0) return `${h}j ${m}m ${s}d`;
  if (m > 0) return `${m}m ${s}d`;
  return `${s}d`;
}
