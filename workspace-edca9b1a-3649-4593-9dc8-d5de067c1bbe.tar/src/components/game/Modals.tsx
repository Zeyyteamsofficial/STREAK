"use client";
// ===== STREAK — Modals =====
import React, { useState } from "react";
import type { GameState } from "@/lib/game/types";
import type { MutationType } from "@/lib/game/types";
import { MUTATIONS, STREAK_REWARDS, STAGES } from "@/lib/game/data";
import * as engine from "@/lib/game/engine";
import { DIALOGUES } from "@/lib/game/data";
import { randChoice } from "@/lib/game/engine";

// ===== Death Modal =====
export function DeathModal({ state, onRetry }: { state: GameState; onRetry: (name: string) => void }) {
  const d = state.dragon!;
  const [name, setName] = useState("");
  const [stage, setStage] = useState<"death" | "legacy" | "retry">("death");
  const days = engine.dragonAgeDays(d);

  return (
    <div className="fixed inset-0 z-50 bg-black/80 flex items-center justify-center p-4">
      <div className="bg-gradient-to-b from-slate-800 to-slate-900 rounded-3xl p-6 max-w-md w-full text-center streak-pop border border-slate-700 shadow-2xl">
        {stage === "death" && (
          <>
            <div className="text-7xl mb-3 streak-ghost">💀</div>
            <h2 className="text-2xl font-black text-red-400 mb-1">{d.name} Telah Mati</h2>
            <p className="text-slate-400 text-sm mb-4">
              {d.name} hidup selama <span className="font-bold text-white">{days} hari</span> dan mencapai tahap <span className="font-bold text-white">{STAGES[d.stage].name}</span>.
            </p>
            <p className="text-slate-500 text-xs mb-5">Penyebab: {d.causeOfDeath}</p>
            <button
              onClick={() => setStage("legacy")}
              className="w-full py-3 rounded-xl bg-gradient-to-r from-amber-500 to-orange-600 text-white font-bold hover:opacity-90 active:scale-95 transition"
            >
              Lihat Warisan →
            </button>
          </>
        )}

        {stage === "legacy" && (
          <>
            <div className="text-6xl mb-3">🏛️</div>
            <h2 className="text-xl font-black text-amber-400 mb-3">Legacy System</h2>
            <div className="bg-slate-800/60 rounded-xl p-4 mb-4 space-y-2 text-left">
              <div className="flex items-center gap-2 text-sm">
                <span className="text-2xl">🎖️</span>
                <span className="text-slate-300">Badge Keturunan diterima</span>
              </div>
              <div className="flex items-center gap-2 text-sm">
                <span className="text-2xl">⚡</span>
                <span className="text-slate-300">Bonus pertumbuhan +5% (total {Math.min(25, state.legacy.bonus)}%)</span>
              </div>
              <div className="flex items-center gap-2 text-sm">
                <span className="text-2xl">📜</span>
                <span className="text-slate-300">Rekor umur: {state.legacy.recordDays} hari</span>
              </div>
              <div className="flex items-center gap-2 text-sm">
                <span className="text-2xl">🐉</span>
                <span className="text-slate-300">Generasi berikutnya: ke-{state.legacy.generation}</span>
              </div>
            </div>
            <p className="text-slate-400 text-xs mb-4">Naga berikutnya akan mewarisi bonus ini. Streak tetap berlanjut!</p>
            <button
              onClick={() => setStage("retry")}
              className="w-full py-3 rounded-xl bg-gradient-to-r from-green-500 to-emerald-600 text-white font-bold hover:opacity-90 active:scale-95 transition"
            >
              Mulai Generasi Baru →
            </button>
          </>
        )}

        {stage === "retry" && (
          <>
            <div className="text-6xl mb-3 streak-bounce inline-block">🥚</div>
            <h2 className="text-xl font-black text-green-400 mb-1">Telur Baru Menanti</h2>
            <p className="text-slate-400 text-sm mb-4">Beri nama naga generasi ke-{state.legacy.generation}:</p>
            <input
              type="text"
              value={name}
              onChange={(e) => setName(e.target.value)}
              maxLength={16}
              placeholder="Nama naga baru..."
              className="w-full px-4 py-3 rounded-xl bg-slate-800 border border-slate-600 text-white placeholder-slate-500 outline-none focus:border-green-400 mb-3"
              autoFocus
            />
            <button
              onClick={() => onRetry(name || `Naga Gen ${state.legacy.generation}`)}
              className="w-full py-3 rounded-xl bg-gradient-to-r from-green-500 to-emerald-600 text-white font-bold hover:opacity-90 active:scale-95 transition"
            >
              🐣 Mulai Ulang dari Telur
            </button>
          </>
        )}
      </div>
    </div>
  );
}

// ===== Mutation Modal =====
export function MutationModal({ onChoose }: { onChoose: (m: MutationType) => void }) {
  const options = MUTATIONS.filter((m) => m.id !== "none");
  return (
    <div className="fixed inset-0 z-50 bg-black/80 flex items-center justify-center p-4">
      <div className="bg-gradient-to-b from-purple-900 to-slate-900 rounded-3xl p-6 max-w-md w-full streak-pop border border-purple-700 shadow-2xl">
        <div className="text-center mb-4">
          <div className="text-6xl mb-2 streak-bounce inline-block">🧬</div>
          <h2 className="text-2xl font-black text-purple-300">Mutasi Terdeteksi!</h2>
          <p className="text-slate-400 text-sm mt-1">Streak tinggimu telah membangkitkan kekuatan elemen. Pilih mutasi nagamu!</p>
        </div>
        <div className="grid grid-cols-1 gap-2">
          {options.map((m) => (
            <button
              key={m.id}
              onClick={() => onChoose(m.id as MutationType)}
              className="flex items-center gap-3 p-3 rounded-xl bg-slate-800/60 hover:bg-slate-700/60 active:scale-95 transition border border-slate-700 text-left"
            >
              <div className="w-12 h-12 rounded-full flex items-center justify-center text-2xl" style={{ background: `radial-gradient(circle, ${m.color}, ${m.accent})`, boxShadow: `0 0 16px ${m.glow}` }}>
                {m.emoji}
              </div>
              <div className="flex-1">
                <div className="font-bold text-white">{m.name}</div>
                <p className="text-xs text-slate-400">{m.desc}</p>
              </div>
              <span className="text-slate-500">→</span>
            </button>
          ))}
        </div>
      </div>
    </div>
  );
}

// ===== Reward Modal (chest) =====
export function RewardModal({ state, onClose }: { state: GameState; onClose: () => void }) {
  // This is shown when pendingReward exists; but we auto-claim. Show a celebration.
  return null;
}

// ===== Ghost Modal =====
export function GhostModal({ state, onClose }: { state: GameState; onClose: () => void }) {
  const [line] = useState(() => {
    const ghostLines = state.history.length > 0
      ? [
        randChoice(DIALOGUES.ghost),
        `Aku dulu hidup ${state.history[0].daysLived} hari...`,
        `Namaku ${state.history[0].name}. Jaga generasi berikutnya...`,
        "Dunia ini indah dulu...",
      ]
      : DIALOGUES.ghost;
    return randChoice(ghostLines);
  });
  return (
    <div className="fixed inset-0 z-50 bg-black/70 flex items-center justify-center p-4" onClick={onClose}>
      <div className="bg-gradient-to-b from-slate-800 to-slate-950 rounded-3xl p-6 max-w-sm w-full text-center streak-pop border border-slate-700">
        <div className="text-7xl mb-3 streak-ghost">👻🐉</div>
        <p className="text-slate-300 italic text-lg mb-1">"{line}"</p>
        {state.history[0] && (
          <p className="text-slate-500 text-xs mt-2">— {state.history[0].name}, hidup {state.history[0].daysLived} hari</p>
        )}
        <button onClick={onClose} className="mt-5 px-6 py-2 rounded-xl bg-slate-700 text-slate-200 font-bold hover:bg-slate-600 active:scale-95 transition">
          Selamat jalan...
        </button>
      </div>
    </div>
  );
}

// ===== Daily Check-in Modal =====
export function DailyCheckInModal({ state, onClose, onCheckIn }: {
  state: GameState; onClose: () => void; onCheckIn: () => void;
}) {
  const [checked, setChecked] = useState(false);
  const hoursSince = (Date.now() - state.streak.lastCheckIn) / (1000 * 60 * 60);
  const canCheckIn = state.streak.lastCheckIn === 0 || hoursSince >= 20;

  const handleCheckIn = () => {
    onCheckIn();
    setChecked(true);
    setTimeout(onClose, 1800);
  };

  return (
    <div className="fixed inset-0 z-40 bg-black/60 flex items-center justify-center p-4" onClick={onClose}>
      <div className="bg-white rounded-3xl p-5 max-w-sm w-full streak-pop" onClick={(e) => e.stopPropagation()}>
        <div className="text-center">
          <div className="text-5xl mb-2">🔥</div>
          <h2 className="font-black text-xl text-slate-800">Check-in Harian</h2>
          <p className="text-sm text-slate-500 mt-1">Jaga streakmu setiap hari untuk hadiah!</p>
        </div>

        <div className="my-4 p-4 rounded-2xl bg-gradient-to-r from-orange-50 to-amber-50 border border-orange-200 text-center">
          <div className="text-4xl font-black text-orange-600">{state.streak.current}</div>
          <div className="text-xs text-slate-500 font-semibold">Hari Streak Saat Ini</div>
          <div className="text-xs text-slate-400 mt-1">Rekor: {state.streak.record} hari</div>
        </div>

        {/* Upcoming rewards */}
        <div className="mb-4">
          <h3 className="text-xs font-bold text-slate-600 mb-1.5">🎁 Hadiah Streak Berikutnya:</h3>
          <div className="space-y-1">
            {STREAK_REWARDS.slice(0, 4).map((sr) => {
              const claimed = state.streak.claimedDayRewards.includes(sr.day);
              const isNext = sr.day === state.streak.current + 1 || (state.streak.current < sr.day && !claimed);
              return (
                <div key={sr.day} className={`flex items-center gap-2 p-2 rounded-lg text-xs ${claimed ? "bg-green-50 text-green-600" : isNext ? "bg-amber-100 text-amber-700 font-bold" : "bg-slate-50 text-slate-500"}`}>
                  <span className="text-lg">{sr.chest === "epic" ? "💎" : sr.chest === "rare" ? "🎁" : "📦"}</span>
                  <span className="flex-1">Hari {sr.day}: {sr.label}</span>
                  {claimed && <span>✓</span>}
                </div>
              );
            })}
          </div>
        </div>

        {checked ? (
          <div className="w-full py-3 rounded-xl bg-green-500 text-white font-bold text-center streak-pop">
            ✓ Check-in Berhasil!
          </div>
        ) : canCheckIn ? (
          <button
            onClick={handleCheckIn}
            className="w-full py-3 rounded-xl bg-gradient-to-r from-orange-500 to-red-500 text-white font-bold hover:opacity-90 active:scale-95 transition"
          >
            ✓ Check-in Hari Ini (+10 🪙)
          </button>
        ) : (
          <div className="w-full py-3 rounded-xl bg-slate-100 text-slate-400 font-bold text-center">
            Sudah check-in hari ini
          </div>
        )}
        <button onClick={onClose} className="w-full mt-2 py-2 rounded-xl text-slate-500 text-sm font-semibold hover:bg-slate-50">
          Tutup
        </button>
      </div>
    </div>
  );
}
