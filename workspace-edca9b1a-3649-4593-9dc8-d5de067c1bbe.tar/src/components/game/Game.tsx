"use client";
// ===== STREAK — Main Game Container =====
import React, { useState, useEffect, useRef, useCallback } from "react";
import { useGame } from "@/lib/game/useGame";
import * as engine from "@/lib/game/engine";
import { STAGES, AREAS, GAME_VERSION, GAME_MAKER, DIALOGUES } from "@/lib/game/data";
import { isNight } from "@/lib/game/engine";
import { speak, dragonVoice } from "@/lib/game/audio";
import DragonSprite from "./DragonSprite";
import Scene from "./Scene";
import {
  ShopPanel, InventoryPanel, MissionsPanel, StatsPanel, HistoryPanel,
  AreasPanel, AchievementsPanel, SettingsPanel, GrowthPanel, BondPanel, SkinPanel,
} from "./Panels";
import MiniGame from "./MiniGame";
import {
  DeathModal, MutationModal, RewardModal, GhostModal, DailyCheckInModal,
} from "./Modals";

type PanelType =
  | null | "shop" | "inventory" | "missions" | "stats" | "history"
  | "areas" | "achievements" | "settings" | "growth" | "bond" | "skin" | "minigame";

interface Toast {
  id: number;
  msg: string;
  type: "info" | "success" | "error" | "achievement";
}

export default function Game() {
  const game = useGame();
  const [panel, setPanel] = useState<PanelType>(null);
  const [toasts, setToasts] = useState<Toast[]>([]);
  const [showMenu, setShowMenu] = useState(false);
  const [clickFx, setClickFx] = useState<{ id: number; x: number; y: number; emoji: string }[]>([]);
  const [now, setNow] = useState(Date.now());
  const toastId = useRef(0);

  // tick clock for timer UI
  useEffect(() => {
    const i = setInterval(() => setNow(Date.now()), 1000);
    return () => clearInterval(i);
  }, []);

  // register toast handler
  useEffect(() => {
    game.registerToast((msg, type = "info") => {
      const id = ++toastId.current;
      setToasts((t) => [...t, { id, msg, type }].slice(-4));
      setTimeout(() => setToasts((t) => t.filter((x) => x.id !== id)), 3500);
    });
     
  }, []);

  const state = game.state;

  // Loading / no state
  if (!state) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-sky-100">
        <div className="text-slate-600 animate-pulse">Memuat STREAK...</div>
      </div>
    );
  }

  // Name setup screen
  if (!state.user || !state.dragon) {
    return <NameSetup onStart={game.startGame} />;
  }

  const dragon = state.dragon;
  const moodInfo = engine.effectiveMood(dragon);
  const isDead = dragon.health === "dead";
  const stageInfo = STAGES[dragon.stage];
  const night = isNight();
  const area = AREAS.find((a) => a.id === state.areas.current) || AREAS[0];

  const handleDragonClick = (e: React.MouseEvent) => {
    if (isDead) return;
    const rect = (e.currentTarget as HTMLElement).getBoundingClientRect();
    const x = e.clientX - rect.left;
    const y = e.clientY - rect.top;
    const id = Date.now() + Math.random();
    const emojis = ["✨", "💛", "🌟", "💖", "🐉"];
    const emoji = emojis[Math.floor(Math.random() * emojis.length)];
    setClickFx((f) => [...f, { id, x, y, emoji }]);
    setTimeout(() => setClickFx((f) => f.filter((c) => c.id !== id)), 800);
    game.clickDragon();
    // occasional voice
    if (Math.random() < 0.3) {
      dragonVoice(moodInfo.type);
    }
  };

  return (
    <div className="min-h-screen flex flex-col bg-slate-900 select-none overflow-hidden">
      {/* ===== Top Bar ===== */}
      <header className="relative z-30 bg-white/80 backdrop-blur-md border-b border-black/10 shadow-sm">
        <div className="max-w-3xl mx-auto px-2 sm:px-3 py-2 flex items-center gap-1.5 sm:gap-2 flex-wrap">
          {/* Logo */}
          <div className="flex items-center gap-1.5 font-black text-base sm:text-lg">
            <span className="text-orange-500">🔥</span>
            <span className="bg-gradient-to-r from-orange-500 to-red-500 bg-clip-text text-transparent">STREAK</span>
          </div>
          {/* Resources */}
          <ResourceChip icon="🪙" value={state.resources.coins} label="Koin" color="text-amber-600" />
          <ResourceChip icon="💎" value={state.resources.gems} label="Gem" color="text-cyan-600" />
          <ResourceChip icon="🍖" value={state.resources.food} label="Makanan" color="text-rose-600" />
          <ResourceChip icon="🔥" value={state.streak.current} label="Streak" color="text-orange-600" />
          <div className="flex-1" />
          {/* Day/Night */}
          <div className="text-lg" title={night ? "Malam" : "Siang"}>{night ? "🌙" : "☀️"}</div>
          {/* Daily check-in */}
          <button
            onClick={() => setPanel("__checkin__" as PanelType)}
            className="px-2 py-1 rounded-lg bg-green-500 text-white text-xs font-bold hover:bg-green-600 active:scale-95 transition shadow-sm"
            title="Check-in harian"
          >
            ✓ Hadir
          </button>
        </div>
        {/* Dragon name + stage + area */}
        <div className="max-w-3xl mx-auto px-2 sm:px-3 pb-1.5 flex items-center gap-2 text-xs text-slate-600">
          <span className="font-bold text-slate-800">{dragon.name}</span>
          <span className="text-slate-400">·</span>
          <span>{stageInfo.emoji} {stageInfo.name}</span>
          <span className="text-slate-400">·</span>
          <span>{area.emoji} {area.name}</span>
          <span className="text-slate-400">·</span>
          <span>Gen {dragon.generation}</span>
          {dragon.mutation !== "none" && (
            <>
              <span className="text-slate-400">·</span>
              <span>{mutationEmoji(dragon.mutation)} {mutationName(dragon.mutation)}</span>
            </>
          )}
          <div className="flex-1" />
          <span className="text-slate-400">{dragonAgeText(dragon)}</span>
        </div>
      </header>

      {/* ===== Main Scene ===== */}
      <main className="relative flex-1 overflow-hidden">
        <Scene state={state} />

        {/* Dragon interactive area */}
        <div className="absolute inset-0 flex items-end justify-center pb-[28%] sm:pb-[22%]">
          <div className="relative" style={{ touchAction: "manipulation" }}>
            {/* Ghost dragon */}
            {state.ghostShown && state.history.length > 0 && !isDead && (
              <button
                onClick={() => setPanel("__ghost__" as PanelType)}
                className="absolute -left-20 sm:-left-28 top-0 streak-ghost cursor-pointer"
                title="Hantu naga"
              >
                <div className="text-5xl opacity-50">👻🐉</div>
              </button>
            )}

            {/* Bubble chat */}
            {state.bubble && !isDead && (
              <div className="absolute -top-2 left-1/2 -translate-x-1/2 -translate-y-full z-20 max-w-[200px]">
                <div className="relative bg-white rounded-2xl px-3 py-2 text-xs sm:text-sm font-medium text-slate-800 shadow-lg streak-pop">
                  {state.bubble.text}
                  <div className="absolute -bottom-1.5 left-1/2 -translate-x-1/2 w-3 h-3 bg-white rotate-45" />
                </div>
              </div>
            )}

            <div onClick={handleDragonClick} className="cursor-pointer active:scale-95 transition-transform">
              <DragonSprite
                stage={dragon.stage}
                mood={moodInfo.type}
                mutation={dragon.mutation}
                skin={dragon.skin}
                sleeping={moodInfo.type === "sleeping"}
                sick={dragon.health === "sick"}
                dead={isDead}
                accessory={dragon.accessory}
                size={isMobileSize() ? 220 : 280}
              />
            </div>

            {/* Click particles */}
            {clickFx.map((fx) => (
              <div
                key={fx.id}
                className="absolute pointer-events-none text-2xl streak-float-up"
                style={{ left: fx.x, top: fx.y }}
              >
                {fx.emoji}
              </div>
            ))}

            {/* Poop indicators */}
            {dragon.poopCount > 0 && !isDead && (
              <button
                onClick={game.clean}
                className="absolute -right-4 bottom-2 text-2xl active:scale-90 transition streak-bounce"
                title="Bersihkan kotoran"
              >
                {Array.from({ length: Math.min(dragon.poopCount, 4) }).map((_, i) => (
                  <span key={i} className="inline-block" style={{ marginLeft: i > 0 ? -8 : 0 }}>💩</span>
                ))}
              </button>
            )}

            {/* Mood badge */}
            {!isDead && (
              <div className="absolute -top-1 -right-2 bg-white/90 rounded-full px-2 py-0.5 text-xs font-bold shadow flex items-center gap-1">
                <span>{moodInfo.emoji}</span>
                <span className="text-slate-700">{moodInfo.label}</span>
              </div>
            )}
          </div>
        </div>

        {/* Event banners */}
        {state.events.map((evt) => (
          <button
            key={evt.id}
            onClick={() => game.collectEvent(evt.id)}
            className="absolute top-2 left-1/2 -translate-x-1/2 z-20 streak-bounce"
          >
            <div className="bg-gradient-to-r from-purple-500 to-pink-500 text-white px-3 py-1.5 rounded-full text-xs font-bold shadow-lg flex items-center gap-1">
              {eventEmoji(evt.type)} {eventLabel(evt.type)} — Klik untuk klaim!
            </div>
          </button>
        ))}

        {/* Pending reward chest */}
        {state.pendingReward && (
          <button
            onClick={game.claimPendingReward}
            className="absolute bottom-2 right-2 z-20 streak-chest-glow"
          >
            <div className="text-4xl">🎁</div>
          </button>
        )}
      </main>

      {/* ===== Stat Bars ===== */}
      <div className="relative z-20 bg-white/85 backdrop-blur-md border-t border-black/10 px-2 sm:px-3 py-2">
        <div className="max-w-3xl mx-auto grid grid-cols-2 sm:grid-cols-5 gap-1.5 sm:gap-2">
          <StatBar label="Kenyang" value={100 - dragon.hunger} color="bg-orange-500" icon="🍖" />
          <StatBar label="Mood" value={dragon.mood} color="bg-pink-500" icon={moodInfo.emoji} />
          <StatBar label="Energi" value={dragon.energy} color="bg-yellow-500" icon="⚡" />
          <StatBar label="Bond" value={dragon.bond} color="bg-red-500" icon="❤️" />
          <StatBar label="Berat" value={dragon.weight} color={dragon.weight > 75 ? "bg-red-500" : dragon.weight < 25 ? "bg-amber-500" : "bg-green-500"} icon={dragon.weight > 75 ? "🤰" : dragon.weight < 25 ? "🥵" : "⚖️"} />
        </div>
        {/* Growth progress */}
        {!isDead && dragon.stage < STAGES.length - 1 && (
          <div className="max-w-3xl mx-auto mt-1.5">
            <div className="flex items-center gap-2 text-xs text-slate-600">
              <span className="font-semibold whitespace-nowrap">🌱 Pertumbuhan:</span>
              <div className="flex-1 h-2 bg-slate-200 rounded-full overflow-hidden">
                <div
                  className="h-full bg-gradient-to-r from-green-400 to-emerald-500 transition-all"
                  style={{ width: `${engine.stageProgress(dragon)}%` }}
                />
              </div>
              <span className="whitespace-nowrap text-slate-500">{formatMs(engine.msToHatch(dragon))}</span>
              <button onClick={() => setPanel("growth")} className="text-slate-400 hover:text-slate-600" title="Detail pertumbuhan">ℹ️</button>
            </div>
          </div>
        )}
      </div>

      {/* ===== Action Bar ===== */}
      <footer className="relative z-30 bg-white border-t border-black/10 shadow-[0_-2px_8px_rgba(0,0,0,0.05)]">
        <div className="max-w-3xl mx-auto px-2 py-2 flex items-center gap-1.5 sm:gap-2 justify-around">
          <ActionButton emoji="🍖" label="Makan" onClick={() => setPanel("__feed__" as PanelType)} disabled={isDead} color="bg-orange-100 hover:bg-orange-200 text-orange-700" />
          <ActionButton emoji="🤚" label="Elus" onClick={game.pet} disabled={isDead} color="bg-pink-100 hover:bg-pink-200 text-pink-700" />
          <ActionButton emoji="🎾" label="Main" onClick={game.play} disabled={isDead} color="bg-purple-100 hover:bg-purple-200 text-purple-700" />
          <ActionButton emoji="🧹" label="Bersih" onClick={game.clean} disabled={isDead} color="bg-teal-100 hover:bg-teal-200 text-teal-700" />
          <ActionButton emoji="🎮" label="Game" onClick={() => setPanel("minigame")} disabled={isDead} color="bg-indigo-100 hover:bg-indigo-200 text-indigo-700" />
          <ActionButton emoji="📋" label="Menu" onClick={() => setShowMenu(true)} color="bg-slate-100 hover:bg-slate-200 text-slate-700" />
        </div>
      </footer>

      {/* ===== Menu Grid ===== */}
      {showMenu && (
        <MenuGrid
          onClose={() => setShowMenu(false)}
          onOpen={(p) => { setShowMenu(false); setPanel(p); }}
          state={state}
        />
      )}

      {/* ===== Panels ===== */}
      {panel === "shop" && <ShopPanel state={state} onClose={() => setPanel(null)} onBuy={game.buyItem} onBuySkin={game.buySkin} />}
      {panel === "inventory" && <InventoryPanel state={state} onClose={() => setPanel(null)} onUse={game.useItem} onEquip={game.equipAccessory} onEquipSkin={game.equipSkin} />}
      {panel === "missions" && <MissionsPanel state={state} onClose={() => setPanel(null)} onClaim={game.claimMission} onReroll={game.rerollMissions} />}
      {panel === "stats" && <StatsPanel state={state} onClose={() => setPanel(null)} />}
      {panel === "history" && <HistoryPanel state={state} onClose={() => setPanel(null)} />}
      {panel === "areas" && <AreasPanel state={state} onClose={() => setPanel(null)} onChange={game.changeArea} />}
      {panel === "achievements" && <AchievementsPanel state={state} onClose={() => setPanel(null)} />}
      {panel === "settings" && <SettingsPanel state={state} onClose={() => setPanel(null)} onUpdate={game.updateSettings} onRename={game.renameDragon} onReset={game.resetGame} />}
      {panel === "growth" && <GrowthPanel state={state} onClose={() => setPanel(null)} />}
      {panel === "bond" && <BondPanel state={state} onClose={() => setPanel(null)} />}
      {panel === "skin" && <SkinPanel state={state} onClose={() => setPanel(null)} onEquip={game.equipSkin} onBuy={game.buySkin} />}
      {panel === "minigame" && <MiniGame state={state} onClose={() => setPanel(null)} onReward={game.giveMiniGameReward} />}

      {/* Feeding quick panel */}
      {panel === ("__feed__" as PanelType) && (
        <FeedQuickPanel state={state} onClose={() => setPanel(null)} onFeedFree={game.feedFree} onFeed={game.feed} onOpenShop={() => setPanel("shop")} />
      )}
      {/* Daily check-in */}
      {panel === ("__checkin__" as PanelType) && (
        <DailyCheckInModal state={state} onClose={() => setPanel(null)} onCheckIn={game.dailyCheckIn} />
      )}
      {/* Ghost dragon */}
      {panel === ("__ghost__" as PanelType) && (
        <GhostModal state={state} onClose={() => { setPanel(null); game.dismissGhost(); }} />
      )}

      {/* ===== Modals ===== */}
      {isDead && <DeathModal state={state} onRetry={game.retryDragon} />}
      {state.pendingMutation && <MutationModal onChoose={game.applyMutation} />}

      {/* ===== Toasts ===== */}
      <div className="fixed top-16 left-1/2 -translate-x-1/2 z-50 flex flex-col items-center gap-1.5 pointer-events-none w-full max-w-sm px-2">
        {toasts.map((t) => (
          <div
            key={t.id}
            className={`streak-pop pointer-events-auto rounded-xl px-3 py-2 text-sm font-medium shadow-lg max-w-full text-center ${
              t.type === "success" ? "bg-green-500 text-white" :
              t.type === "error" ? "bg-red-500 text-white" :
              t.type === "achievement" ? "bg-gradient-to-r from-amber-400 to-orange-500 text-white" :
              "bg-slate-800 text-white"
            }`}
          >
            {t.msg}
          </div>
        ))}
      </div>

      {/* ===== Footer credit ===== */}
      <div className="sr-only">STREAK v{GAME_VERSION} by {GAME_MAKER}</div>
    </div>
  );
}

// ===== Sub-components =====

function isMobileSize() {
  if (typeof window === "undefined") return false;
  return window.innerWidth < 640;
}

function mutationEmoji(m: string) {
  return { fire: "🔥", ice: "❄️", lightning: "⚡", nature: "🌿", shadow: "🌑", none: "✨" }[m] || "✨";
}
function mutationName(m: string) {
  return { fire: "Api", ice: "Es", lightning: "Petir", nature: "Alam", shadow: "Bayangan", none: "Normal" }[m] || m;
}

function dragonAgeText(dragon: { eggCreatedAt: number }) {
  const days = Math.floor((Date.now() - dragon.eggCreatedAt) / (1000 * 60 * 60 * 24));
  if (days <= 0) return "Baru lahir";
  return `${days} hari`;
}

function eventEmoji(t: string) {
  return { rain: "☔", birthday: "🎂", meteor: "🌠", gift: "🎁" }[t] || "🎉";
}
function eventLabel(t: string) {
  return { rain: "Hujan", birthday: "Ulang Tahun", meteor: "Meteor", gift: "Hadiah" }[t] || "Event";
}

function formatMs(ms: number) {
  if (ms <= 0) return "Siap!";
  const totalSec = Math.floor(ms / 1000);
  const d = Math.floor(totalSec / 86400);
  const h = Math.floor((totalSec % 86400) / 3600);
  const m = Math.floor((totalSec % 3600) / 60);
  const s = totalSec % 60;
  if (d > 0) return `${d}h ${h}j ${m}m`;
  if (h > 0) return `${h}j ${m}m ${s}d`;
  if (m > 0) return `${m}m ${s}d`;
  return `${s}d`;
}

function ResourceChip({ icon, value, label, color }: { icon: string; value: number; label: string; color: string }) {
  return (
    <div className="flex items-center gap-1 bg-white rounded-full px-2 py-0.5 shadow-sm border border-black/5" title={label}>
      <span className="text-sm">{icon}</span>
      <span className={`text-xs font-bold ${color}`}>{value}</span>
    </div>
  );
}

function StatBar({ label, value, color, icon }: { label: string; value: number; color: string; icon: string }) {
  return (
    <div className="flex items-center gap-1.5">
      <span className="text-sm">{icon}</span>
      <div className="flex-1">
        <div className="flex justify-between text-[10px] font-semibold text-slate-500 mb-0.5">
          <span>{label}</span>
          <span>{Math.round(value)}</span>
        </div>
        <div className="h-1.5 bg-slate-200 rounded-full overflow-hidden">
          <div className={`h-full ${color} transition-all duration-500`} style={{ width: `${Math.max(0, Math.min(100, value))}%` }} />
        </div>
      </div>
    </div>
  );
}

function ActionButton({ emoji, label, onClick, disabled, color }: { emoji: string; label: string; onClick: () => void; disabled?: boolean; color: string }) {
  return (
    <button
      onClick={onClick}
      disabled={disabled}
      className={`flex flex-col items-center justify-center gap-0.5 rounded-xl px-2 sm:px-3 py-1.5 min-w-[52px] sm:min-w-[64px] transition active:scale-90 disabled:opacity-40 disabled:cursor-not-allowed ${color}`}
    >
      <span className="text-xl sm:text-2xl">{emoji}</span>
      <span className="text-[10px] sm:text-xs font-bold">{label}</span>
    </button>
  );
}

function MenuGrid({ onClose, onOpen, state }: { onClose: () => void; onOpen: (p: PanelType) => void; state: import("@/lib/game/types").GameState }) {
  const items: { emoji: string; label: string; panel: PanelType; badge?: number }[] = [
    { emoji: "🛒", label: "Toko", panel: "shop" },
    { emoji: "🎒", label: "Inventaris", panel: "inventory" },
    { emoji: "📜", label: "Misi", panel: "missions", badge: state.missions.missions.filter((m) => m.done && !m.claimed).length },
    { emoji: "🗺️", label: "Area", panel: "areas" },
    { emoji: "📈", label: "Statistik", panel: "stats" },
    { emoji: "🐉", label: "Pertumbuhan", panel: "growth" },
    { emoji: "❤️", label: "Bond", panel: "bond" },
    { emoji: "🎨", label: "Kulit Naga", panel: "skin" },
    { emoji: "📚", label: "Buku Sejarah", panel: "history" },
    { emoji: "🏅", label: "Achievement", panel: "achievements" },
    { emoji: "🎮", label: "Mini Game", panel: "minigame" },
    { emoji: "⚙️", label: "Pengaturan", panel: "settings" },
  ];
  return (
    <div className="fixed inset-0 z-40 bg-black/50 flex items-end sm:items-center justify-center" onClick={onClose}>
      <div className="bg-white w-full sm:max-w-md sm:rounded-2xl rounded-t-2xl p-4 streak-pop max-h-[80vh] overflow-y-auto streak-scroll" onClick={(e) => e.stopPropagation()}>
        <div className="flex items-center justify-between mb-3">
          <h2 className="font-black text-lg">📋 Menu</h2>
          <button onClick={onClose} className="w-8 h-8 rounded-full bg-slate-100 hover:bg-slate-200 flex items-center justify-center">✕</button>
        </div>
        <div className="grid grid-cols-3 sm:grid-cols-4 gap-2">
          {items.map((it) => (
            <button
              key={it.panel}
              onClick={() => onOpen(it.panel)}
              className="relative flex flex-col items-center gap-1 p-3 rounded-xl bg-slate-50 hover:bg-slate-100 active:scale-95 transition border border-slate-200"
            >
              <span className="text-2xl">{it.emoji}</span>
              <span className="text-[11px] font-semibold text-slate-700 text-center leading-tight">{it.label}</span>
              {it.badge ? (
                <span className="absolute -top-1 -right-1 bg-red-500 text-white text-[10px] font-bold rounded-full w-5 h-5 flex items-center justify-center">{it.badge}</span>
              ) : null}
            </button>
          ))}
        </div>
      </div>
    </div>
  );
}

// ===== Name Setup Screen =====
function NameSetup({ onStart }: { onStart: (playerName: string, dragonName: string) => void }) {
  const [name, setName] = useState("");
  const [dragonName, setDragonName] = useState("");
  const [step, setStep] = useState(0);

  return (
    <div className="min-h-screen flex flex-col items-center justify-center bg-gradient-to-b from-sky-300 via-sky-200 to-green-300 p-4 overflow-hidden relative">
      {/* decorative clouds */}
      <div className="absolute top-10 left-10 text-6xl opacity-80 streak-cloud-drift" style={{ animationDuration: "80s" }}>☁️</div>
      <div className="absolute top-20 right-10 text-5xl opacity-70 streak-cloud-drift" style={{ animationDuration: "100s", animationDelay: "10s" }}>☁️</div>
      <div className="absolute top-6 right-1/3 text-4xl opacity-60 streak-cloud-drift" style={{ animationDuration: "120s" }}>☀️</div>
      {/* ground */}
      <div className="absolute bottom-0 left-0 right-0 h-1/4 bg-gradient-to-t from-green-500 to-green-400" />
      <div className="absolute bottom-2 left-8 text-4xl">🌳</div>
      <div className="absolute bottom-4 right-10 text-5xl">🌲</div>
      <div className="absolute bottom-3 left-1/3 text-3xl">🌷</div>

      <div className="relative z-10 w-full max-w-md bg-white/90 backdrop-blur rounded-3xl shadow-2xl p-6 streak-pop">
        {/* Logo */}
        <div className="text-center mb-4">
          <div className="inline-flex items-center gap-2 font-black text-3xl mb-1">
            <span className="text-orange-500">🔥</span>
            <span className="bg-gradient-to-r from-orange-500 to-red-500 bg-clip-text text-transparent">STREAK</span>
          </div>
          <p className="text-sm text-slate-500">Game Naga Peliharaan — v{GAME_VERSION}</p>
          <p className="text-xs text-slate-400">oleh {GAME_MAKER}</p>
        </div>

        {step === 0 ? (
          <>
            <div className="text-center mb-4">
              <div className="text-6xl mb-2 streak-bounce inline-block">🥚</div>
              <h2 className="font-bold text-lg text-slate-800">Selamat Datang!</h2>
              <p className="text-sm text-slate-600 mt-1">Rawat naga peliharaanmu dari telur hingga menjadi Naga Super Kuat. Jaga streak harianmu!</p>
            </div>
            <label className="block text-sm font-semibold text-slate-700 mb-1">Nama Pemain</label>
            <input
              type="text"
              value={name}
              onChange={(e) => setName(e.target.value)}
              placeholder="Masukkan namamu..."
              maxLength={20}
              className="w-full px-4 py-3 rounded-xl border-2 border-slate-200 focus:border-orange-400 outline-none text-slate-800"
              onKeyDown={(e) => { if (e.key === "Enter" && name.trim()) setStep(1); }}
            />
            <button
              onClick={() => name.trim() && setStep(1)}
              disabled={!name.trim()}
              className="w-full mt-4 py-3 rounded-xl bg-gradient-to-r from-orange-500 to-red-500 text-white font-bold hover:opacity-90 active:scale-95 transition disabled:opacity-40"
            >
              Lanjut →
            </button>
          </>
        ) : (
          <>
            <div className="text-center mb-4">
              <div className="text-6xl mb-2 streak-bounce inline-block">🐲</div>
              <h2 className="font-bold text-lg text-slate-800">Beri Nama Nagamu</h2>
              <p className="text-sm text-slate-600 mt-1">Nagamu akan menetas dari telur dalam 1 hari!</p>
            </div>
            <label className="block text-sm font-semibold text-slate-700 mb-1">Nama Naga</label>
            <input
              type="text"
              value={dragonName}
              onChange={(e) => setDragonName(e.target.value)}
              placeholder="Contoh: Drako, Ignis, Ryu..."
              maxLength={16}
              className="w-full px-4 py-3 rounded-xl border-2 border-slate-200 focus:border-orange-400 outline-none text-slate-800"
              onKeyDown={(e) => { if (e.key === "Enter" && dragonName.trim()) onStart(name, dragonName); }}
              autoFocus
            />
            <div className="flex gap-2 mt-4">
              <button
                onClick={() => setStep(0)}
                className="px-4 py-3 rounded-xl bg-slate-100 text-slate-600 font-bold hover:bg-slate-200 active:scale-95 transition"
              >
                ← Kembali
              </button>
              <button
                onClick={() => onStart(name, dragonName)}
                disabled={!dragonName.trim()}
                className="flex-1 py-3 rounded-xl bg-gradient-to-r from-orange-500 to-red-500 text-white font-bold hover:opacity-90 active:scale-95 transition disabled:opacity-40"
              >
                🐣 Mulai Petualangan!
              </button>
            </div>
          </>
        )}

        {/* Feature preview */}
        <div className="mt-5 pt-4 border-t border-slate-100 grid grid-cols-3 gap-2 text-center">
          <div><div className="text-xl">🔥</div><div className="text-[10px] text-slate-500">Streak Harian</div></div>
          <div><div className="text-xl">🧬</div><div className="text-[10px] text-slate-500">Mutasi Elemen</div></div>
          <div><div className="text-xl">🏆</div><div className="text-[10px] text-slate-500">Legacy System</div></div>
        </div>
      </div>
    </div>
  );
}

// ===== Feed Quick Panel =====
function FeedQuickPanel({ state, onClose, onFeedFree, onFeed, onOpenShop }: {
  state: import("@/lib/game/types").GameState;
  onClose: () => void;
  onFeedFree: () => void;
  onFeed: (amount: number) => void;
  onOpenShop: () => void;
}) {
  return (
    <div className="fixed inset-0 z-40 bg-black/50 flex items-end sm:items-center justify-center" onClick={onClose}>
      <div className="bg-white w-full sm:max-w-md sm:rounded-2xl rounded-t-2xl p-4 streak-pop" onClick={(e) => e.stopPropagation()}>
        <div className="flex items-center justify-between mb-3">
          <h2 className="font-black text-lg">🍖 Beri Makan</h2>
          <button onClick={onClose} className="w-8 h-8 rounded-full bg-slate-100 hover:bg-slate-200 flex items-center justify-center">✕</button>
        </div>
        <p className="text-xs text-slate-500 mb-3">Nafsu makan nagamu saat ini: <span className="font-bold">{state.dragon?.appetite === "low" ? "🤢 Kurang nafsu" : state.dragon?.appetite === "high" ? "🤤 Sangat lapar" : "😊 Normal"}</span></p>
        <div className="space-y-2">
          <button
            onClick={() => { onFeedFree(); }}
            disabled={state.resources.food <= 0}
            className="w-full flex items-center gap-3 p-3 rounded-xl bg-orange-50 hover:bg-orange-100 active:scale-95 transition border border-orange-200 disabled:opacity-40"
          >
            <span className="text-3xl">🍖</span>
            <div className="text-left flex-1">
              <div className="font-bold text-slate-800">Makanan Gratis</div>
              <div className="text-xs text-slate-500">+50 kenyang · Sisa: {state.resources.food}</div>
            </div>
            <span className="text-xs font-bold text-orange-600">GRATIS</span>
          </button>

          {/* Food items in inventory */}
          {state.inventory.filter((i) => i.type === "food").map((item) => {
            const info = { feed20: 20, feed45: 45, feed60: 60, feed100: 100 }[item.itemId.replace("food_", "feed")] || 50;
            return (
              <button
                key={item.id}
                onClick={() => onFeed(info)}
                className="w-full flex items-center gap-3 p-3 rounded-xl bg-amber-50 hover:bg-amber-100 active:scale-95 transition border border-amber-200"
              >
                <span className="text-3xl">{item.icon}</span>
                <div className="text-left flex-1">
                  <div className="font-bold text-slate-800">{item.name}</div>
                  <div className="text-xs text-slate-500">+{info} kenyang</div>
                </div>
                <span className="text-xs font-bold text-amber-600">x{item.qty}</span>
              </button>
            );
          })}

          <button
            onClick={() => { onClose(); onOpenShop(); }}
            className="w-full p-3 rounded-xl bg-slate-50 hover:bg-slate-100 transition border border-dashed border-slate-300 text-sm text-slate-600 font-semibold"
          >
            🛒 Beli makanan lain di toko
          </button>
        </div>
      </div>
    </div>
  );
}
