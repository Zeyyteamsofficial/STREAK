// ===== STREAK — Audio System =====
// Made by GabutZ — v1.5
// Uses Web Audio API for SFX + SpeechSynthesis for Indonesian dragon voice.
// Custom audio files can be dropped into AUDIO_FILES map (key -> dataURL/path).

type VoiceLineKey =
  | "happy" | "angry" | "sad" | "anxious" | "sick" | "sleeping" | "hungry"
  | "greeting" | "long_gone" | "ghost" | "evolve" | "click" | "death" | "reward";

// ====== CUSTOM AUDIO SLOT ======
// To use your own audio files, assign data URLs or paths here.
// e.g. AUDIO_FILES.dragonHappy = "/audio/dragon-happy.mp3"
// Leave null to use synthesized/default behavior.
export const AUDIO_FILES: Record<string, string | null> = {
  dragonHappy: null,
  dragonAngry: null,
  dragonSad: null,
  dragonAnxious: null,
  dragonSick: null,
  dragonSleeping: null,
  dragonHungry: null,
  click: null,
  feed: null,
  pet: null,
  evolve: null,
  reward: null,
  death: null,
  rain: null,
  musicDay: null,
  musicNight: null,
  musicRain: null,
};

let ctx: AudioContext | null = null;
let masterGain: GainNode | null = null;
let musicNodes: { osc: OscillatorNode; gain: GainNode }[] = [];
let currentMusic: "day" | "night" | "rain" | null = null;
let soundEnabled = true;
let musicEnabled = true;
let voiceEnabled = true;

function getCtx(): AudioContext | null {
  if (typeof window === "undefined") return null;
  if (!ctx) {
    try {
      ctx = new (window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext)();
      masterGain = ctx.createGain();
      masterGain.gain.value = 0.25;
      masterGain.connect(ctx.destination);
    } catch {
      return null;
    }
  }
  if (ctx && ctx.state === "suspended") ctx.resume().catch(() => {});
  return ctx;
}

export function setSoundEnabled(v: boolean) {
  soundEnabled = v;
}
export function setMusicEnabled(v: boolean) {
  musicEnabled = v;
  if (!v) stopMusic();
}
export function setVoiceEnabled(v: boolean) {
  voiceEnabled = v;
}

// Simple tone synth
function tone(freq: number, duration: number, type: OscillatorType = "sine", vol = 0.3, when = 0) {
  const c = getCtx();
  if (!c || !masterGain) return;
  const osc = c.createOscillator();
  const g = c.createGain();
  osc.type = type;
  osc.frequency.value = freq;
  g.gain.setValueAtTime(0, c.currentTime + when);
  g.gain.linearRampToValueAtTime(vol, c.currentTime + when + 0.01);
  g.gain.exponentialRampToValueAtTime(0.001, c.currentTime + when + duration);
  osc.connect(g);
  g.connect(masterGain);
  osc.start(c.currentTime + when);
  osc.stop(c.currentTime + when + duration + 0.05);
}

// Play a custom audio file if available, else fallback
function playFile(key: string): boolean {
  const file = AUDIO_FILES[key];
  if (!file) return false;
  try {
    const audio = new Audio(file);
    audio.volume = 0.4;
    audio.play().catch(() => {});
    return true;
  } catch {
    return false;
  }
}

// ===== SFX =====
export function sfxClick() {
  if (!soundEnabled) return;
  if (playFile("click")) return;
  tone(660, 0.08, "triangle", 0.2);
}

export function sfxFeed() {
  if (!soundEnabled) return;
  if (playFile("feed")) return;
  tone(440, 0.1, "sine", 0.25);
  tone(550, 0.1, "sine", 0.25, 0.1);
  tone(660, 0.12, "sine", 0.25, 0.2);
}

export function sfxPet() {
  if (!soundEnabled) return;
  if (playFile("pet")) return;
  tone(800, 0.06, "sine", 0.2);
  tone(1000, 0.06, "sine", 0.2, 0.06);
}

export function sfxEvolve() {
  if (!soundEnabled) return;
  if (playFile("evolve")) return;
  [523, 659, 784, 1046].forEach((f, i) => tone(f, 0.25, "triangle", 0.3, i * 0.12));
}

export function sfxReward() {
  if (!soundEnabled) return;
  if (playFile("reward")) return;
  [659, 784, 1046, 1318].forEach((f, i) => tone(f, 0.2, "sine", 0.3, i * 0.08));
}

export function sfxDeath() {
  if (!soundEnabled) return;
  if (playFile("death")) return;
  tone(300, 0.4, "sawtooth", 0.25);
  tone(200, 0.5, "sawtooth", 0.25, 0.2);
  tone(120, 0.7, "sawtooth", 0.25, 0.4);
}

export function sfxError() {
  if (!soundEnabled) return;
  tone(200, 0.15, "square", 0.2);
  tone(150, 0.15, "square", 0.2, 0.1);
}

export function sfxCoin() {
  if (!soundEnabled) return;
  tone(988, 0.08, "square", 0.18);
  tone(1319, 0.1, "square", 0.18, 0.08);
}

// ===== Dragon vocalization (synthesized) =====
export function dragonVoice(mood: VoiceLineKey) {
  if (!soundEnabled) return;
  const fileMap: Record<string, string> = {
    happy: "dragonHappy",
    angry: "dragonAngry",
    sad: "dragonSad",
    anxious: "dragonAnxious",
    sick: "dragonSick",
    sleeping: "dragonSleeping",
    hungry: "dragonHungry",
  };
  const fileKey = fileMap[mood];
  if (fileKey && playFile(fileKey)) return;
  // Synthesized dragon chirp/growl per mood
  const c = getCtx();
  if (!c || !masterGain) return;
  if (mood === "happy" || mood === "greeting") {
    tone(700, 0.1, "sine", 0.25);
    tone(900, 0.12, "sine", 0.25, 0.08);
    tone(1100, 0.1, "sine", 0.2, 0.16);
  } else if (mood === "angry" || mood === "hungry") {
    tone(180, 0.3, "sawtooth", 0.3);
    tone(140, 0.35, "sawtooth", 0.25, 0.1);
  } else if (mood === "sad" || mood === "anxious" || mood === "sick") {
    tone(300, 0.4, "sine", 0.2);
    tone(250, 0.5, "sine", 0.18, 0.2);
  } else if (mood === "sleeping") {
    tone(220, 0.5, "sine", 0.12);
    tone(200, 0.6, "sine", 0.1, 0.4);
  } else if (mood === "evolve") {
    sfxEvolve();
  } else if (mood === "reward") {
    sfxReward();
  } else if (mood === "death") {
    sfxDeath();
  } else if (mood === "click") {
    tone(600, 0.08, "triangle", 0.2);
  }
}

// ===== Speech Synthesis (Indonesian voice lines) =====
export function speak(text: string) {
  if (!voiceEnabled) return;
  if (typeof window === "undefined" || !window.speechSynthesis) return;
  try {
    window.speechSynthesis.cancel();
    const u = new SpeechSynthesisUtterance(text);
    u.lang = "id-ID";
    u.rate = 1.0;
    u.pitch = 1.3;
    u.volume = 0.8;
    // Try to find Indonesian voice
    const voices = window.speechSynthesis.getVoices();
    const idVoice = voices.find((v) => v.lang.startsWith("id"));
    if (idVoice) u.voice = idVoice;
    window.speechSynthesis.speak(u);
  } catch {
    // ignore
  }
}

// ===== Ambient Music (looping pad) =====
function startPad(freqs: number[], type: OscillatorType, vol: number) {
  const c = getCtx();
  if (!c || !masterGain) return;
  stopMusic();
  freqs.forEach((f) => {
    const osc = c.createOscillator();
    const g = c.createGain();
    osc.type = type;
    osc.frequency.value = f;
    g.gain.value = 0;
    g.gain.linearRampToValueAtTime(vol, c.currentTime + 1.5);
    // gentle LFO
    const lfo = c.createOscillator();
    const lfoGain = c.createGain();
    lfo.frequency.value = 0.1 + Math.random() * 0.1;
    lfoGain.gain.value = vol * 0.4;
    lfo.connect(lfoGain);
    lfoGain.connect(g.gain);
    lfo.start();
    osc.connect(g);
    g.connect(masterGain!);
    osc.start();
    musicNodes.push({ osc, gain: g });
    // store lfo to stop later
    musicNodes.push({ osc: lfo, gain: lfoGain });
  });
}

export function stopMusic() {
  const c = getCtx();
  if (!c) return;
  musicNodes.forEach(({ osc, gain }) => {
    try {
      gain.gain.linearRampToValueAtTime(0, c.currentTime + 0.5);
      osc.stop(c.currentTime + 0.6);
    } catch {
      // ignore
    }
  });
  musicNodes = [];
  currentMusic = null;
}

export function playMusic(kind: "day" | "night" | "rain") {
  if (!musicEnabled) return;
  if (currentMusic === kind) return;
  // Use custom file if available
  const fileKey = kind === "day" ? "musicDay" : kind === "night" ? "musicNight" : "musicRain";
  if (AUDIO_FILES[fileKey]) {
    stopMusic();
    try {
      const audio = new Audio(AUDIO_FILES[fileKey]!);
      audio.loop = true;
      audio.volume = 0.25;
      audio.play().catch(() => {});
      currentMusic = kind;
    } catch {
      // ignore
    }
    return;
  }
  if (kind === "day") {
    startPad([261.63, 329.63, 392.0], "sine", 0.04);
  } else if (kind === "night") {
    startPad([130.81, 196.0, 246.94], "sine", 0.035);
  } else if (kind === "rain") {
    startPad([220, 277.18], "triangle", 0.03);
    // add noise-ish rain via fast amplitude tremolo
  }
  currentMusic = kind;
}

export function rainSfx() {
  if (!soundEnabled) return;
  if (playFile("rain")) return;
  // light raindrops
  for (let i = 0; i < 6; i++) {
    tone(2000 + Math.random() * 1000, 0.03, "sine", 0.05, i * 0.12);
  }
}
