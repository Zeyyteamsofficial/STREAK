// ===== STREAK — Storage (localStorage persistence) =====
import type { GameState } from "./types";
import { createInitialState } from "./engine";
import { GAME_VERSION, STORAGE_KEY } from "./data";

export function loadState(): GameState {
  if (typeof window === "undefined") return createInitialState();
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) return createInitialState();
    const parsed = JSON.parse(raw) as GameState;
    if (parsed.version !== GAME_VERSION) {
      // migrate / reset on version mismatch — merge with defaults
      const base = createInitialState();
      return { ...base, ...parsed, version: GAME_VERSION };
    }
    return parsed;
  } catch {
    return createInitialState();
  }
}

export function saveState(state: GameState) {
  if (typeof window === "undefined") return;
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(state));
  } catch {
    // storage full / unavailable — ignore
  }
}

export function clearSave() {
  if (typeof window === "undefined") return;
  localStorage.removeItem(STORAGE_KEY);
}
