// ===== STREAK — Game Engine (pure logic) =====
// Made by GabutZ — v1.5
import type {
  GameState,
  Dragon,
  Mission,
  ChestReward,
  Rarity,
  MutationType,
  DragonStage,
  DragonRecord,
} from "./types";
import {
  STAGES,
  AREAS,
  SKINS,
  MUTATIONS,
  ITEMS,
  CHEST_POOLS,
  STREAK_REWARDS,
  MISSION_TEMPLATES,
  DIALOGUES,
  DAILY_FREE_FOOD,
  DAY_MS,
  HOUR_MS,
  MISSION_RESET_MS,
  MISSION_REROLL_COST,
  DOUBLE_GROWTH_DURATION,
  GAME_VERSION,
} from "./data";

// ===== Helpers =====
export const clamp = (v: number, min = 0, max = 100) => Math.max(min, Math.min(max, v));
export const randInt = (min: number, max: number) => Math.floor(Math.random() * (max - min + 1)) + min;
export const randChoice = <T,>(arr: T[]): T => arr[Math.floor(Math.random() * arr.length)];
export const randFloat = (min: number, max: number) => Math.random() * (max - min) + min;

export function isNight(date = new Date()): boolean {
  const h = date.getHours();
  return h >= 18 || h < 6;
}

export function isDayTime(date = new Date()): boolean {
  return !isNight(date);
}

export function hoursSince(ts: number): number {
  return (Date.now() - ts) / HOUR_MS;
}
export function daysSince(ts: number): number {
  return (Date.now() - ts) / DAY_MS;
}

export function msToHatch(dragon: Dragon): number {
  const stage = STAGES[dragon.stage];
  const elapsed = Date.now() - dragon.stageStartedAt;
  return Math.max(0, stage.durationMs - elapsed);
}

export function stageProgress(dragon: Dragon): number {
  const stage = STAGES[dragon.stage];
  const elapsed = Date.now() - dragon.stageStartedAt;
  return clamp((elapsed / stage.durationMs) * 100, 0, 100);
}

export function dragonAgeDays(dragon: Dragon): number {
  return Math.floor((Date.now() - dragon.eggCreatedAt) / DAY_MS);
}

// ===== Effective mood computation =====
export function effectiveMood(dragon: Dragon): {
  type: import("./types").MoodType;
  label: string;
  emoji: string;
} {
  if (dragon.health === "dead") return { type: "sad", label: "Mati", emoji: "💀" };
  if (isNight() && dragon.energy < 35) return { type: "sleeping", label: "Tidur", emoji: "😴" };
  if (dragon.health === "sick") return { type: "sick", label: "Sakit", emoji: "🤒" };
  if (dragon.hunger > 75) return { type: "hungry", label: "Lapar", emoji: "🍴" };
  if (dragon.mood < 30) {
    // angry if hungry, sad if just low
    if (dragon.hunger > 50) return { type: "angry", label: "Marah", emoji: "😠" };
    return { type: "sad", label: "Sedih", emoji: "😢" };
  }
  if (dragon.mood < 50) return { type: "anxious", label: "Gelisah", emoji: "😟" };
  if (dragon.mood >= 70) return { type: "happy", label: "Senang", emoji: "😄" };
  return { type: "happy", label: "Biasa", emoji: "🙂" };
}

// ===== Initial State =====
export function createInitialState(): GameState {
  return {
    version: GAME_VERSION,
    user: null,
    dragon: null,
    streak: { current: 0, record: 0, lastCheckIn: 0, claimedDayRewards: [] },
    resources: { coins: 50, gems: 5, food: DAILY_FREE_FOOD, lastFoodRefill: Date.now() },
    inventory: [],
    areas: { unlocked: ["meadow"], current: "meadow" },
    missions: { missions: [], generatedAt: 0, rerollCost: MISSION_REROLL_COST },
    achievements: { unlocked: [] },
    history: [],
    legacy: { generation: 1, bonus: 0, recordDays: 0, totalDragons: 0 },
    gamepass: { owned: [], doubleGrowthUntil: 0 },
    stats: {
      totalFood: 0, totalClicks: 0, totalPets: 0, totalPlays: 0, totalCleaned: 0,
      totalCoinsEarned: 0, totalGemsEarned: 0, miniGamesPlayed: 0, daysActive: 0, chestsOpened: 0,
    },
    settings: { sound: true, music: true, voice: true },
    events: [],
    lastSeen: Date.now(),
    bubble: null,
    pendingReward: null,
    pendingMutation: false,
    ghostShown: false,
    introSeen: false,
  };
}

// ===== Create new dragon (egg) =====
export function createDragon(name: string, generation = 1): Dragon {
  const now = Date.now();
  return {
    name: name || "Naga",
    skin: "classic",
    stage: 0,
    eggCreatedAt: now,
    stageStartedAt: now,
    lastFedAt: now,
    lastSickAt: null,
    diedAt: null,
    hunger: 20,
    mood: 70,
    energy: 80,
    bond: 10,
    health: "healthy",
    weight: 50,
    mutation: "none",
    mutationUnlockedAt: null,
    poopCount: 0,
    lastPoopAt: now,
    accessory: null,
    appetite: "normal",
    appetiteChangedAt: now,
    generation,
    causeOfDeath: null,
  };
}

// ===== Generate daily missions =====
export function generateMissions(): Mission[] {
  const count = 3;
  const picked = new Set<string>();
  const missions: Mission[] = [];
  const templates = [...MISSION_TEMPLATES];
  while (missions.length < count && templates.length > 0) {
    const idx = randInt(0, templates.length - 1);
    const tpl = templates.splice(idx, 1)[0];
    const target = randChoice(tpl.targets);
    const rewardCoins = randInt(tpl.rewardCoins[0], tpl.rewardCoins[1]);
    const id = `${tpl.type}_${target}_${Math.random().toString(36).slice(2, 7)}`;
    if (picked.has(tpl.type)) continue;
    picked.add(tpl.type);
    missions.push({
      id,
      desc: tpl.desc(target),
      type: tpl.type,
      target,
      progress: 0,
      rewardCoins,
      rewardGems: tpl.rewardGems,
      done: false,
      claimed: false,
    });
  }
  return missions;
}

// ===== Tick: apply time-based changes =====
export function tick(state: GameState): GameState {
  if (!state.dragon || state.dragon.health === "dead") {
    return { ...state, lastSeen: Date.now() };
  }
  const d = { ...state.dragon };
  const now = Date.now();
  const night = isNight();
  const dtHrs = Math.min(1, (now - state.lastSeen) / HOUR_MS); // cap at 1hr per tick to avoid huge jumps within session

  // Hunger increases over time
  const hungerRate = 100 / 24; // per hour
  d.hunger = clamp(d.hunger + hungerRate * dtHrs);

  // Energy: drains day, regens night
  if (night) {
    d.energy = clamp(d.energy + 8 * dtHrs);
  } else {
    d.energy = clamp(d.energy - 3 * dtHrs);
  }

  // Mood decay/gain
  let moodDelta = -1.5 * dtHrs; // baseline decay
  if (d.hunger > 70) moodDelta -= 3 * dtHrs;
  if (d.health === "sick") moodDelta -= 4 * dtHrs;
  if (d.poopCount >= 3) moodDelta -= 2 * dtHrs;
  if (d.bond > 60) moodDelta += 1 * dtHrs; // high bond keeps mood up
  if (d.hunger < 30 && d.health === "healthy") moodDelta += 1.5 * dtHrs;
  d.mood = clamp(d.mood + moodDelta);

  // Weight drift toward extremes based on hunger
  if (d.hunger > 90) {
    d.weight = clamp(d.weight - 1.5 * dtHrs); // starving -> thin
  }

  // Poop accumulates (every ~5 hours)
  if (now - d.lastPoopAt > 5 * HOUR_MS && d.poopCount < 6) {
    d.poopCount += 1;
    d.lastPoopAt = now;
  }

  // Appetite changes every ~8 hours
  if (now - d.appetiteChangedAt > 8 * HOUR_MS) {
    const r = Math.random();
    d.appetite = r < 0.33 ? "low" : r < 0.66 ? "normal" : "high";
    d.appetiteChangedAt = now;
  }

  // Sickness from hunger (24h no food)
  if (d.health === "healthy" && d.hunger >= 100 && now - d.lastFedAt > DAY_MS) {
    d.health = "sick";
    d.lastSickAt = now;
  }
  // Sickness from obesity
  if (d.health === "healthy" && d.weight > 80) {
    d.health = "sick";
    d.lastSickAt = now;
  }
  // Sickness from starvation (too thin)
  if (d.health === "healthy" && d.weight < 20) {
    d.health = "sick";
    d.lastSickAt = now;
  }

  // Death from sickness (24h sick untreated)
  if (d.health === "sick" && d.lastSickAt && now - d.lastSickAt > DAY_MS) {
    d.health = "dead";
    d.diedAt = now;
    if (d.weight > 80) d.causeOfDeath = "Obesitas";
    else if (d.weight < 20) d.causeOfDeath = "Kekurangan gizi";
    else d.causeOfDeath = "Kelaparan";
  }

  // Growth / evolution
  if (d.health !== "dead" && d.stage < STAGES.length - 1) {
    const stage = STAGES[d.stage];
    let duration = stage.durationMs;
    // double growth gamepass
    if (state.gamepass.doubleGrowthUntil > now) duration /= 2;
    // legacy bonus
    if (state.legacy.bonus > 0) duration = duration * (1 - state.legacy.bonus / 100);
    if (now - d.stageStartedAt >= duration) {
      d.stage = (d.stage + 1) as DragonStage;
      d.stageStartedAt = now;
      // mutation unlock at stage >= 5 (naga biasa) and high streak
      if (d.stage >= 5 && d.mutation === "none" && state.streak.current >= 30 && !d.mutationUnlockedAt) {
        // flag pending mutation for UI
      }
    }
  }

  // Free daily food refill
  const res = { ...state.resources };
  if (now - res.lastFoodRefill >= DAY_MS) {
    res.food = DAILY_FREE_FOOD;
    res.lastFoodRefill = now;
  }

  // Streak: if last check-in > 2 days ago, streak resets (but only if a dragon exists long enough)
  const streak = { ...state.streak };
  if (streak.lastCheckIn > 0 && now - streak.lastCheckIn > 2 * DAY_MS) {
    if (streak.current > 0) {
      streak.current = 0;
    }
  }

  return {
    ...state,
    dragon: d,
    resources: res,
    streak,
    lastSeen: now,
  };
}

// ===== Actions =====
export function feedDragon(state: GameState, foodAmount: number): { state: GameState; ok: boolean; msg: string } {
  if (!state.dragon || state.dragon.health === "dead") return { state, ok: false, msg: "Naga tidak ada." };
  const d = { ...state.dragon };
  const moodInfo = effectiveMood(d);

  // Mood-based feeding difficulty
  // If sad/anxious/sick/angry, harder to feed (may refuse)
  const refuseChance =
    moodInfo.type === "sick" ? 0.55 :
    moodInfo.type === "anxious" ? 0.4 :
    moodInfo.type === "sad" ? 0.3 :
    moodInfo.type === "angry" ? 0.35 :
    moodInfo.type === "sleeping" ? 0.6 : 0;

  // Appetite modifies amount accepted
  let acceptedMult = 1;
  if (d.appetite === "low") acceptedMult = 0.5;
  if (d.appetite === "high") acceptedMult = 1.4;

  if (Math.random() < refuseChance) {
    // Refused — mood drops a bit
    d.mood = clamp(d.mood - 5);
    return { state: { ...state, dragon: d }, ok: false, msg: `${d.name} menolak makanan! (${moodLabel(moodInfo.type)})` };
  }

  const accepted = Math.round(foodAmount * acceptedMult);
  d.hunger = clamp(d.hunger - accepted);
  d.lastFedAt = Date.now();

  // Weight logic: feeding when not very hungry → obesity risk
  if (d.hunger < 30) {
    d.weight = clamp(d.weight + 8); // overfeeding
  } else {
    d.weight = clamp(d.weight + 2);
  }

  // Mood up
  d.mood = clamp(d.mood + 8);
  d.bond = clamp(d.bond + 2);

  // Cure sickness if hunger restored enough and weight normal
  if (d.health === "sick" && d.hunger < 40 && d.weight >= 25 && d.weight <= 75) {
    d.health = "healthy";
    d.lastSickAt = null;
  }

  // Mission progress
  const missions = progressMissions(state.missions.missions, "feed", 1);
  // Stats
  const stats = { ...state.stats, totalFood: state.stats.totalFood + 1 };

  return {
    state: { ...state, dragon: d, missions: { ...state.missions, missions }, stats },
    ok: true,
    msg: `${d.name} makan dengan lahap! +${accepted} kenyang`,
  };
}

function moodLabel(type: string): string {
  const map: Record<string, string> = {
    happy: "Senang", angry: "Marah", sad: "Sedih", anxious: "Gelisah", sick: "Sakit", sleeping: "Tidur", hungry: "Lapar",
  };
  return map[type] || type;
}

export function petDragon(state: GameState): { state: GameState; msg: string } {
  if (!state.dragon || state.dragon.health === "dead") return { state, msg: "Naga tidak ada." };
  const d = { ...state.dragon };
  const moodInfo = effectiveMood(d);
  // sleeping dragon gets slightly annoyed
  if (moodInfo.type === "sleeping") {
    d.mood = clamp(d.mood - 2);
    return { state: { ...state, dragon: d }, msg: `${d.name} sedang tidur... jangan ganggu!` };
  }
  d.mood = clamp(d.mood + 6);
  d.bond = clamp(d.bond + 4);
  const missions = progressMissions(state.missions.missions, "pet", 1);
  const stats = { ...state.stats, totalPets: state.stats.totalPets + 1, totalClicks: state.stats.totalClicks + 1 };
  return {
    state: { ...state, dragon: d, missions: { ...state.missions, missions }, stats },
    msg: `${d.name} senang dielus! Bond +4`,
  };
}

export function playWithDragon(state: GameState): { state: GameState; msg: string } {
  if (!state.dragon || state.dragon.health === "dead") return { state, msg: "Naga tidak ada." };
  const d = { ...state.dragon };
  if (d.energy < 20) return { state, msg: `${d.name} terlalu lelah untuk bermain. Biarkan istirahat.` };
  if (effectiveMood(d).type === "sleeping") return { state, msg: `${d.name} sedang tidur.` };
  d.mood = clamp(d.mood + 12);
  d.bond = clamp(d.bond + 6);
  d.energy = clamp(d.energy - 15);
  d.hunger = clamp(d.hunger + 5);
  const missions = progressMissions(state.missions.missions, "play", 1);
  const stats = { ...state.stats, totalPlays: state.stats.totalPlays + 1 };
  return {
    state: { ...state, dragon: d, missions: { ...state.missions, missions }, stats },
    msg: `${d.name} bermain gembira! Mood +12, Bond +6`,
  };
}

export function cleanPoop(state: GameState): { state: GameState; msg: string } {
  if (!state.dragon || state.dragon.health === "dead") return { state, msg: "Naga tidak ada." };
  if (state.dragon.poopCount <= 0) return { state, msg: "Tidak ada kotoran untuk dibersihkan." };
  const d = { ...state.dragon, poopCount: 0, lastPoopAt: Date.now() };
  d.mood = clamp(d.mood + 5);
  const missions = progressMissions(state.missions.missions, "clean", 1);
  const stats = { ...state.stats, totalCleaned: state.stats.totalCleaned + 1 };
  return {
    state: { ...state, dragon: d, missions: { ...state.missions, missions }, stats },
    msg: "Kandang bersih! Naga lebih nyaman.",
  };
}

export function clickDragon(state: GameState): { state: GameState; msg: string } {
  if (!state.dragon || state.dragon.health === "dead") return { state, msg: "" };
  const d = { ...state.dragon };
  d.bond = clamp(d.bond + 0.3);
  const missions = progressMissions(state.missions.missions, "click", 1);
  const stats = { ...state.stats, totalClicks: state.stats.totalClicks + 1 };
  return { state: { ...state, dragon: d, missions: { ...state.missions, missions }, stats }, msg: "" };
}

// ===== Mission progress =====
export function progressMissions(missions: Mission[], type: Mission["type"], amount: number): Mission[] {
  return missions.map((m) => {
    if (m.type === type && !m.done) {
      const progress = Math.min(m.target, m.progress + amount);
      return { ...m, progress, done: progress >= m.target };
    }
    return m;
  });
}

export function claimMission(state: GameState, missionId: string): { state: GameState; msg: string } {
  const mission = state.missions.missions.find((m) => m.id === missionId);
  if (!mission || !mission.done || mission.claimed) return { state, msg: "Misi tidak valid." };
  const res = { ...state.resources };
  res.coins += mission.rewardCoins;
  res.gems += mission.rewardGems;
  const stats = { ...state.stats, totalCoinsEarned: state.stats.totalCoinsEarned + mission.rewardCoins, totalGemsEarned: state.stats.totalGemsEarned + mission.rewardGems };
  const missions = state.missions.missions.map((m) => (m.id === missionId ? { ...m, claimed: true } : m));
  return {
    state: { ...state, resources: res, missions: { ...state.missions, missions }, stats },
    msg: `Hadiah diterima! +${mission.rewardCoins} koin${mission.rewardGems ? ` +${mission.rewardGems} gem` : ""}`,
  };
}

export function rerollMissions(state: GameState): { state: GameState; ok: boolean; msg: string } {
  if (state.resources.gems < MISSION_REROLL_COST) {
    return { state, ok: false, msg: "Gem tidak cukup! Butuh 5 gem." };
  }
  const res = { ...state.resources, gems: state.resources.gems - MISSION_REROLL_COST };
  return {
    state: { ...state, resources: res, missions: { missions: generateMissions(), generatedAt: Date.now(), rerollCost: MISSION_REROLL_COST } },
    ok: true,
    msg: "Misi baru telah dibuat!",
  };
}

export function maybeResetMissions(state: GameState): GameState {
  if (Date.now() - state.missions.generatedAt > MISSION_RESET_MS) {
    return { ...state, missions: { missions: generateMissions(), generatedAt: Date.now(), rerollCost: MISSION_REROLL_COST } };
  }
  return state;
}

// ===== Daily check-in / streak =====
export function dailyCheckIn(state: GameState): { state: GameState; msg: string; reward?: ChestReward } {
  const now = Date.now();
  const streak = { ...state.streak };
  // First ever check-in
  if (streak.lastCheckIn === 0) {
    streak.current = 1;
    streak.lastCheckIn = now;
  } else {
    const hoursSince = (now - streak.lastCheckIn) / HOUR_MS;
    if (hoursSince >= 20 && hoursSince < 48) {
      streak.current += 1;
      streak.lastCheckIn = now;
    } else if (hoursSince >= 48) {
      streak.current = 1;
      streak.lastCheckIn = now;
    } else {
      // already checked in today
      return { state: { ...state, streak }, msg: "Sudah check-in hari ini. Kembali besok!" };
    }
  }
  streak.record = Math.max(streak.record, streak.current);

  // Coin reward for check-in
  const res = { ...state.resources, coins: state.resources.coins + 10 };
  const stats = { ...state.stats, totalCoinsEarned: state.stats.totalCoinsEarned + 10, daysActive: state.stats.daysActive + 1 };

  // Streak reward chest
  let reward: ChestReward | undefined;
  const newStreak = { ...streak };
  for (const sr of STREAK_REWARDS) {
    if (streak.current === sr.day && !streak.claimedDayRewards.includes(sr.day)) {
      reward = openChest(sr.chest);
      newStreak.claimedDayRewards = [...streak.claimedDayRewards, sr.day];
      break;
    }
  }

  return {
    state: { ...state, streak: newStreak, resources: res, stats, pendingReward: reward || state.pendingReward },
    msg: `Check-in harian! Streak: ${newStreak.current} hari. +10 koin${reward ? " + Peti hadiah!" : ""}`,
    reward,
  };
}

// ===== Chest opening =====
export function openChest(type: "common" | "rare" | "epic"): ChestReward {
  const pool = CHEST_POOLS[type];
  const coins = randInt(pool.coinRange[0], pool.coinRange[1]);
  const gems = randInt(pool.gemRange[0], pool.gemRange[1]);
  const items: ChestReward["items"] = [];
  const usedIds = new Set<string>();
  for (let i = 0; i < pool.itemCount; i++) {
    let itemId = randChoice(pool.itemIds);
    let tries = 0;
    while (usedIds.has(itemId) && tries < 5) {
      itemId = randChoice(pool.itemIds);
      tries++;
    }
    usedIds.add(itemId);
    const info = ITEMS.find((it) => it.id === itemId);
    if (info) {
      items.push({ itemId: info.id, name: info.name, icon: info.icon, rarity: info.rarity, type: info.type });
    }
  }
  return { chestType: type, items, coins, gems };
}

// Apply chest reward to inventory/resources
export function applyReward(state: GameState, reward: ChestReward): GameState {
  const res = { ...state.resources, coins: state.resources.coins + reward.coins, gems: state.resources.gems + reward.gems };
  const stats = { ...state.stats, totalCoinsEarned: state.stats.totalCoinsEarned + reward.coins, totalGemsEarned: state.stats.totalGemsEarned + reward.gems, chestsOpened: state.stats.chestsOpened + 1 };
  let inventory = [...state.inventory];
  for (const item of reward.items) {
    const existing = inventory.find((i) => i.itemId === item.itemId);
    if (existing) {
      inventory = inventory.map((i) => (i.itemId === item.itemId ? { ...i, qty: i.qty + 1 } : i));
    } else {
      inventory.push({
        id: `inv_${Date.now()}_${Math.random().toString(36).slice(2, 6)}`,
        itemId: item.itemId,
        type: item.type as GameState["inventory"][0]["type"],
        name: item.name,
        rarity: item.rarity as Rarity,
        icon: item.icon,
        qty: 1,
      });
    }
  }
  return { ...state, resources: res, inventory, stats, pendingReward: null };
}

// ===== Shop purchase =====
export function buyItem(state: GameState, itemId: string): { state: GameState; ok: boolean; msg: string } {
  const info = ITEMS.find((i) => i.id === itemId);
  if (!info) return { state, ok: false, msg: "Item tidak ditemukan." };
  const res = { ...state.resources };
  if (info.currency === "coins") {
    if (res.coins < info.price) return { state, ok: false, msg: "Koin tidak cukup!" };
    res.coins -= info.price;
  } else {
    if (res.gems < info.price) return { state, ok: false, msg: "Gem tidak cukup!" };
    res.gems -= info.price;
  }

  // Apply effects for consumables/gamepass immediately
  let newState: GameState = { ...state, resources: res };
  if (info.type === "gamepass") {
    if (info.effect === "doublegrowth") {
      newState.gamepass = { ...newState.gamepass, owned: [...newState.gamepass.owned, info.id], doubleGrowthUntil: Date.now() + DOUBLE_GROWTH_DURATION };
    } else if (info.effect === "shield") {
      newState.gamepass = { ...newState.gamepass, owned: [...newState.gamepass.owned, info.id] };
    }
    return { state: newState, ok: true, msg: `${info.name} diaktifkan!` };
  }

  // Add to inventory
  const existing = newState.inventory.find((i) => i.itemId === info.id);
  let inventory: GameState["inventory"];
  if (existing) {
    inventory = newState.inventory.map((i) => (i.itemId === info.id ? { ...i, qty: i.qty + 1 } : i));
  } else {
    inventory = [...newState.inventory, {
      id: `inv_${Date.now()}_${Math.random().toString(36).slice(2, 6)}`,
      itemId: info.id,
      type: info.type,
      name: info.name,
      rarity: info.rarity,
      icon: info.icon,
      qty: 1,
    }];
  }
  return { state: { ...newState, inventory }, ok: true, msg: `${info.name} dibeli!` };
}

// Buy skin
export function buySkin(state: GameState, skinId: string): { state: GameState; ok: boolean; msg: string } {
  const skin = SKINS.find((s) => s.id === skinId);
  if (!skin) return { state, ok: false, msg: "Kulit tidak ditemukan." };
  // check already owned
  if (state.inventory.some((i) => i.itemId === skin.id && i.type === "skin")) {
    return { state, ok: false, msg: "Kulit sudah dimiliki!" };
  }
  if (state.resources.gems < skin.price) return { state, ok: false, msg: "Gem tidak cukup!" };
  const res = { ...state.resources, gems: state.resources.gems - skin.price };
  const inventory = [...state.inventory, {
    id: `inv_${Date.now()}_${Math.random().toString(36).slice(2, 6)}`,
    itemId: skin.id,
    type: "skin" as const,
    name: skin.name,
    rarity: skin.rarity,
    icon: "🎨",
    qty: 1,
  }];
  return { state: { ...state, resources: res, inventory }, ok: true, msg: `Kulit ${skin.name} dibeli!` };
}

export function equipSkin(state: GameState, skinId: string): { state: GameState; ok: boolean; msg: string } {
  if (!state.dragon) return { state, ok: false, msg: "Tidak ada naga." };
  const owned = state.inventory.some((i) => i.itemId === skinId && i.type === "skin") || skinId === "classic";
  if (!owned) return { state, ok: false, msg: "Kulit belum dimiliki." };
  return { state: { ...state, dragon: { ...state.dragon, skin: skinId } }, ok: true, msg: "Kulit diganti!" };
}

export function equipAccessory(state: GameState, itemId: string): { state: GameState; ok: boolean; msg: string } {
  if (!state.dragon) return { state, ok: false, msg: "Tidak ada naga." };
  const inv = state.inventory.find((i) => i.itemId === itemId);
  if (!inv) return { state, ok: false, msg: "Item tidak dimiliki." };
  // toggle equip
  const dragon = { ...state.dragon, accessory: state.dragon.accessory === itemId ? null : itemId };
  return { state: { ...state, dragon }, ok: true, msg: dragon.accessory ? `${inv.name} dipasang!` : "Aksesoris dilepas." };
}

// ===== Use consumable item =====
export function useItem(state: GameState, itemId: string): { state: GameState; ok: boolean; msg: string } {
  if (!state.dragon || state.dragon.health === "dead") return { state, ok: false, msg: "Tidak ada naga." };
  const inv = state.inventory.find((i) => i.itemId === itemId);
  if (!inv || inv.qty <= 0) return { state, ok: false, msg: "Item tidak tersedia." };
  const info = ITEMS.find((it) => it.id === itemId);
  if (!info) return { state, ok: false, msg: "Item tidak dikenal." };

  const d = { ...state.dragon };
  let msg = "";

  if (info.effect === "feed20") { d.hunger = clamp(d.hunger - 20); d.lastFedAt = Date.now(); d.weight = clamp(d.weight + 3); msg = `${d.name} makan apel! +20 kenyang`; }
  else if (info.effect === "feed45") { d.hunger = clamp(d.hunger - 45); d.lastFedAt = Date.now(); d.weight = clamp(d.weight + 4); msg = `${d.name} makan daging! +45 kenyang`; }
  else if (info.effect === "feed60") { d.hunger = clamp(d.hunger - 60); d.lastFedAt = Date.now(); d.mood = clamp(d.mood + 10); d.weight = clamp(d.weight + 4); msg = `${d.name} makan ikan! +60 kenyang, mood naik`; }
  else if (info.effect === "feed100") { d.hunger = 0; d.lastFedAt = Date.now(); d.mood = 100; d.weight = clamp(d.weight + 5); msg = `${d.name} makan Buah Permata! Kenyang penuh, mood max!`; }
  else if (info.effect === "cure") { d.health = "healthy"; d.lastSickAt = null; msg = `${d.name} sembuh dari sakit!`; }
  else if (info.effect === "moodmax") { d.mood = 100; msg = `${d.name} mood-nya naik ke maksimal!`; }
  else if (info.effect === "energymax") { d.energy = 100; msg = `${d.name} energinya penuh kembali!`; }
  else if (info.type === "accessory") {
    return equipAccessory(state, itemId);
  } else if (info.type === "skin") {
    return equipSkin(state, itemId);
  } else {
    return { state, ok: false, msg: "Item ini tidak bisa dipakai langsung." };
  }

  // consume
  const inventory = state.inventory.map((i) => (i.itemId === itemId ? { ...i, qty: i.qty - 1 } : i)).filter((i) => i.qty > 0 || i.type !== "food" && i.type !== "medicine");
  // keep accessories/skins even at 0? they're not qty-based consumables. We'll keep them.
  const stats = info.effect?.startsWith("feed") ? { ...state.stats, totalFood: state.stats.totalFood + 1 } : state.stats;

  return { state: { ...state, dragon: d, inventory, stats }, ok: true, msg };
}

// ===== Death & Legacy =====
export function recordDeath(state: GameState): GameState {
  if (!state.dragon || state.dragon.health !== "dead") return state;
  const d = state.dragon;
  const record: DragonRecord = {
    id: `rec_${Date.now()}`,
    name: d.name,
    daysLived: dragonAgeDays(d),
    stage: d.stage,
    mutation: d.mutation,
    generation: d.generation,
    diedAt: d.diedAt || Date.now(),
    cause: d.causeOfDeath || "Tidak diketahui",
    skin: d.skin,
  };
  const history = [record, ...state.history].slice(0, 50);
  const legacy = {
    ...state.legacy,
    generation: state.legacy.generation + 1,
    recordDays: Math.max(state.legacy.recordDays, record.daysLived),
    totalDragons: state.legacy.totalDragons + 1,
    bonus: Math.min(25, state.legacy.bonus + 5), // +5% each gen, max 25%
  };
  return { ...state, history, legacy };
}

// Retry: new egg, next generation
export function retryDragon(state: GameState, name: string): GameState {
  const newDragon = createDragon(name, state.legacy.generation);
  return {
    ...state,
    dragon: newDragon,
    pendingMutation: false,
    ghostShown: false,
    // keep streak? The user said "gak reset total" for legacy. Streak continues.
    resources: { ...state.resources, food: DAILY_FREE_FOOD, lastFoodRefill: Date.now() },
  };
}

// ===== Mutation =====
export function applyMutation(state: GameState, mutation: MutationType): GameState {
  if (!state.dragon) return state;
  const d = { ...state.dragon, mutation, mutationUnlockedAt: Date.now() };
  return { ...state, dragon: d, pendingMutation: false };
}

export function checkMutationUnlock(state: GameState): GameState {
  if (!state.dragon || state.pendingMutation) return state;
  const d = state.dragon;
  if (d.mutation === "none" && d.stage >= 5 && state.streak.current >= 30 && !d.mutationUnlockedAt) {
    return { ...state, pendingMutation: true };
  }
  return state;
}

// ===== Achievements check =====
export function checkAchievements(state: GameState): { state: GameState; newlyUnlocked: string[] } {
  if (!state.dragon) return { state, newlyUnlocked: [] };
  const unlocked = new Set(state.achievements.unlocked);
  const checks: Record<string, boolean> = {
    first_egg: true,
    seven_days: state.streak.current >= 7 || state.streak.record >= 7,
    first_evo: state.dragon.stage >= 1,
    bond_50: state.dragon.bond >= 50,
    hundred_days: state.streak.record >= 100,
    dragon_king: state.dragon.stage >= 7,
    mutant: state.dragon.mutation !== "none",
    collector: state.inventory.length >= 8,
    rich: state.resources.coins >= 1000 || state.stats.totalCoinsEarned >= 1000,
    legacy_3: state.legacy.generation >= 3,
    explorer: state.areas.unlocked.length >= 4,
    minigamer: state.stats.miniGamesPlayed >= 10,
  };
  const newly: string[] = [];
  for (const [id, ok] of Object.entries(checks)) {
    if (ok && !unlocked.has(id)) {
      unlocked.add(id);
      newly.push(id);
    }
  }
  if (newly.length === 0) return { state, newlyUnlocked: [] };
  return { state: { ...state, achievements: { unlocked: Array.from(unlocked) } }, newlyUnlocked: newly };
}

// ===== Area unlock check =====
export function checkAreaUnlocks(state: GameState): { state: GameState; newlyUnlocked: string[] } {
  const unlocked = new Set(state.areas.unlocked);
  const newly: string[] = [];
  for (const area of AREAS) {
    if (state.streak.record >= area.unlockStreak && !unlocked.has(area.id)) {
      unlocked.add(area.id);
      newly.push(area.id);
    }
  }
  if (newly.length === 0) return { state, newlyUnlocked: [] };
  return { state: { ...state, areas: { ...state.areas, unlocked: Array.from(unlocked) } }, newlyUnlocked: newly };
}

export function changeArea(state: GameState, areaId: string): { state: GameState; ok: boolean; msg: string } {
  if (!state.areas.unlocked.includes(areaId)) return { state, ok: false, msg: "Area belum terbuka!" };
  return { state: { ...state, areas: { ...state.areas, current: areaId } }, ok: true, msg: "Pindah area!" };
}

// ===== Random events =====
export function maybeSpawnEvent(state: GameState): GameState {
  // ~8% chance per check, only if no active event
  if (state.events.length > 0) return state;
  if (Math.random() > 0.08) return state;
  const types: GameState["events"][0]["type"][] = ["rain", "meteor", "gift"];
  // birthday if dragon age matches
  if (state.dragon && dragonAgeDays(state.dragon) > 0 && dragonAgeDays(state.dragon) % 30 === 0) {
    types.push("birthday");
  }
  const type = randChoice(types);
  const duration = type === "rain" ? 20 * 60 * 1000 : type === "meteor" ? 10 * 60 * 1000 : type === "birthday" ? 60 * 60 * 1000 : 15 * 60 * 1000;
  const event = { id: `evt_${Date.now()}`, type, startedAt: Date.now(), endsAt: Date.now() + duration };
  return { ...state, events: [event] };
}

export function clearExpiredEvents(state: GameState): GameState {
  const now = Date.now();
  const events = state.events.filter((e) => e.endsAt > now);
  if (events.length === state.events.length) return state;
  return { ...state, events };
}

export function collectEventReward(state: GameState, eventId: string): { state: GameState; msg: string } {
  const event = state.events.find((e) => e.id === eventId);
  if (!event) return { state, msg: "Event tidak ada." };
  const res = { ...state.resources };
  let msg = "";
  if (event.type === "gift") {
    const coins = randInt(50, 150);
    res.coins += coins;
    msg = `Hadiah misterius! +${coins} koin`;
  } else if (event.type === "meteor") {
    const gems = randInt(1, 3);
    res.gems += gems;
    msg = `Meteor jatuh! +${gems} gem`;
  } else if (event.type === "birthday") {
    res.coins += 100;
    res.gems += 2;
    msg = `Selamat ulang tahun naga! +100 koin, +2 gem`;
  } else {
    msg = "Event berakhir.";
  }
  const stats = { ...state.stats, totalCoinsEarned: state.stats.totalCoinsEarned + (res.coins - state.resources.coins), totalGemsEarned: state.stats.totalGemsEarned + (res.gems - state.resources.gems) };
  const events = state.events.filter((e) => e.id !== eventId);
  return { state: { ...state, resources: res, events, stats }, msg };
}

// ===== Bubble chat =====
export function randomBubble(state: GameState): { text: string; mood: import("./types").MoodType } | null {
  if (!state.dragon || state.dragon.health === "dead") return null;
  if (Math.random() > 0.5) return null; // not every time
  const moodInfo = effectiveMood(state.dragon);
  const lines = DIALOGUES[moodInfo.type] || DIALOGUES.happy;
  return { text: randChoice(lines), mood: moodInfo.type };
}

// ===== React to being left alone =====
export function getReturnMessage(state: GameState): string | null {
  if (!state.dragon) return null;
  const hrs = hoursSince(state.lastSeen);
  if (hrs < 1) return null;
  if (hrs >= 24 * 7) return randChoice(DIALOGUES.long_gone);
  if (hrs >= 24 * 2) return randChoice(DIALOGUES.long_gone);
  if (hrs >= 6) return randChoice(DIALOGUES.greeting);
  return null;
}

// ===== Rename =====
export function renameDragon(state: GameState, name: string): GameState {
  if (!state.dragon) return state;
  return { ...state, dragon: { ...state.dragon, name: name.trim() || "Naga" } };
}

// ===== Mini game reward =====
export function giveMiniGameReward(state: GameState, score: number): { state: GameState; msg: string; gotGem: boolean } {
  const coins = Math.min(200, score * 5);
  const gotGem = Math.random() < 0.12;
  const gems = gotGem ? randInt(1, 2) : 0;
  const res = { ...state.resources, coins: state.resources.coins + coins, gems: state.resources.gems + gems };
  const stats = { ...state.stats, miniGamesPlayed: state.stats.miniGamesPlayed + 1, totalCoinsEarned: state.stats.totalCoinsEarned + coins, totalGemsEarned: state.stats.totalGemsEarned + gems };
  const missions = progressMissions(state.missions.missions, "minigame", 1);
  return {
    state: { ...state, resources: res, stats, missions: { ...state.missions, missions } },
    msg: `Skor ${score}! +${coins} koin${gems ? ` +${gems} gem` : ""}`,
    gotGem,
  };
}

// ===== Ghost dragon =====
export function maybeShowGhost(state: GameState): GameState {
  if (state.ghostShown) return state;
  if (!isNight()) return state;
  if (state.history.length === 0) return state;
  if (state.dragon && state.dragon.health !== "dead") return state; // only when current dragon alive, ghosts of past appear
  if (Math.random() > 0.3) return state;
  return { ...state, ghostShown: true };
}

// ===== Settings =====
export function updateSettings(state: GameState, settings: Partial<GameState["settings"]>): GameState {
  return { ...state, settings: { ...state.settings, ...settings } };
}
