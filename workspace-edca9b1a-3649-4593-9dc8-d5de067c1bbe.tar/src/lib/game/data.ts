// ===== STREAK — Game Data & Constants =====
// Made by GabutZ — v1.5
import type { MutationType, Rarity, Mission } from "./types";

export const GAME_VERSION = "1.5";
export const GAME_MAKER = "GabutZ";

export const STORAGE_KEY = "streak_save_v1_5";
export const DAY_MS = 24 * 60 * 60 * 1000;
export const HOUR_MS = 60 * 60 * 1000;

// ===== Growth Stages =====
// 8 stages: egg -> baby -> big baby -> child -> teen -> normal -> strong -> super
export interface StageInfo {
  id: number;
  name: string;
  emoji: string;
  durationMs: number; // time to stay in this stage before evolving
  desc: string;
  scale: number; // visual scale
}

export const STAGES: StageInfo[] = [
  {
    id: 0,
    name: "Telur Naga",
    emoji: "🥚",
    durationMs: DAY_MS,
    desc: "Menetas dalam 1 hari. Jaga terus!",
    scale: 0.7,
  },
  {
    id: 1,
    name: "Bayi Naga",
    emoji: "🐲",
    durationMs: DAY_MS,
    desc: "Baru menetas! Sangat kecil dan lapar.",
    scale: 0.85,
  },
  {
    id: 2,
    name: "Bayi Naga (Besar)",
    emoji: "🐉",
    durationMs: DAY_MS,
    desc: "Sudah agak besar, sayap mulai tumbuh.",
    scale: 1.0,
  },
  {
    id: 3,
    name: "Anak Naga",
    emoji: "🐉",
    durationMs: 2 * DAY_MS,
    desc: "Anak naga yang aktif! Suka bermain.",
    scale: 1.15,
  },
  {
    id: 4,
    name: "Naga Remaja",
    emoji: "🐉",
    durationMs: 2 * DAY_MS,
    desc: "Naga remaja pemberontak. Mood naik turun.",
    scale: 1.3,
  },
  {
    id: 5,
    name: "Naga Biasa",
    emoji: "🐉",
    durationMs: DAY_MS,
    desc: "Naga dewasa penuh tenaga.",
    scale: 1.45,
  },
  {
    id: 6,
    name: "Naga Kuat",
    emoji: "🐲",
    durationMs: DAY_MS,
    desc: "Naga yang kuat dan gagah.",
    scale: 1.6,
  },
  {
    id: 7,
    name: "NAGA SUPER KUAT",
    emoji: "👑",
    durationMs: 7 * DAY_MS,
    desc: "Puncak evolusi! Legendaris!",
    scale: 1.8,
  },
];

// ===== Mutations =====
export interface MutationInfo {
  id: MutationType;
  name: string;
  emoji: string;
  color: string;
  accent: string;
  glow: string;
  desc: string;
}

export const MUTATIONS: MutationInfo[] = [
  {
    id: "none",
    name: "Normal",
    emoji: "✨",
    color: "#4ade80",
    accent: "#16a34a",
    glow: "rgba(74,222,128,0.5)",
    desc: "Naga biasa tanpa mutasi.",
  },
  {
    id: "fire",
    name: "Api",
    emoji: "🔥",
    color: "#f97316",
    accent: "#dc2626",
    glow: "rgba(249,115,22,0.6)",
    desc: "Naga api! Bernapas api merah.",
  },
  {
    id: "ice",
    name: "Es",
    emoji: "❄️",
    color: "#38bdf8",
    accent: "#0284c7",
    glow: "rgba(56,189,248,0.6)",
    desc: "Naga es! Dingin membekukan.",
  },
  {
    id: "lightning",
    name: "Petir",
    emoji: "⚡",
    color: "#facc15",
    accent: "#ca8a04",
    glow: "rgba(250,204,21,0.6)",
    desc: "Naga petir! Cepat seperti kilat.",
  },
  {
    id: "nature",
    name: "Alam",
    emoji: "🌿",
    color: "#22c55e",
    accent: "#15803d",
    glow: "rgba(34,197,94,0.6)",
    desc: "Naga alam! Satu dengan hutan.",
  },
  {
    id: "shadow",
    name: "Bayangan",
    emoji: "🌑",
    color: "#7c3aed",
    accent: "#4c1d95",
    glow: "rgba(124,58,237,0.6)",
    desc: "Naga bayangan! Misterius dan gelap.",
  },
];

// ===== Skins (cosmetic) =====
export interface SkinInfo {
  id: string;
  name: string;
  body: string;
  belly: string;
  spike: string;
  rarity: Rarity;
  price: number; // gems
  desc: string;
}

export const SKINS: SkinInfo[] = [
  { id: "classic", name: "Klasik Hijau", body: "#4ade80", belly: "#fef9c3", spike: "#16a34a", rarity: "common", price: 0, desc: "Warna hijau klasik." },
  { id: "crimson", name: "Merah Tuan", body: "#ef4444", belly: "#fee2e2", spike: "#991b1b", rarity: "rare", price: 30, desc: "Merah menyala berani." },
  { id: "golden", name: "Emas Royal", body: "#eab308", belly: "#fef3c7", spike: "#a16207", rarity: "epic", price: 60, desc: "Kilau emas kemewahan." },
  { id: "emerald", name: "Zamrud Dalam", body: "#10b981", belly: "#d1fae5", spike: "#047857", rarity: "rare", price: 35, desc: "Hijau zamrud pekat." },
  { id: "sapphire", name: "Safir Laut", body: "#0ea5e9", belly: "#e0f2fe", spike: "#0369a1", rarity: "epic", price: 65, desc: "Biru safir lautan." },
  { id: "obsidian", name: "Obsidian Gelap", body: "#334155", belly: "#cbd5e1", spike: "#0f172a", rarity: "epic", price: 70, desc: "Hitam obsidian misterius." },
  { id: "rose", name: "Mawar Lembut", body: "#fb7185", belly: "#ffe4e6", spike: "#be123c", rarity: "rare", price: 40, desc: "Pink mawar manis." },
  { id: "rainbow", name: "Pelangi Ajaib", body: "rainbow", belly: "#ffffff", spike: "rainbow", rarity: "legendary", price: 150, desc: "Warna pelangi berubah!" },
];

// ===== Areas =====
export interface AreaInfo {
  id: string;
  name: string;
  emoji: string;
  unlockStreak: number;
  skyTop: string;
  skyBottom: string;
  ground: string;
  accent: string;
  desc: string;
}

export const AREAS: AreaInfo[] = [
  {
    id: "meadow",
    name: "Padang Rumput",
    emoji: "🌱",
    unlockStreak: 0,
    skyTop: "#7dd3fc",
    skyBottom: "#bae6fd",
    ground: "#86efac",
    accent: "#4ade80",
    desc: "Padang rumput hijau yang luas.",
  },
  {
    id: "forest",
    name: "Hutan",
    emoji: "🌲",
    unlockStreak: 7,
    skyTop: "#5eead4",
    skyBottom: "#a7f3d0",
    ground: "#15803d",
    accent: "#16a34a",
    desc: "Hutan lebat pohon tinggi.",
  },
  {
    id: "mountain",
    name: "Gunung",
    emoji: "🏔️",
    unlockStreak: 14,
    skyTop: "#bae6fd",
    skyBottom: "#e0f2fe",
    ground: "#94a3b8",
    accent: "#64748b",
    desc: "Puncak gunung dingin.",
  },
  {
    id: "volcanic",
    name: "Vulkanik",
    emoji: "🌋",
    unlockStreak: 21,
    skyTop: "#fdba74",
    skyBottom: "#fecaca",
    ground: "#7c2d12",
    accent: "#ea580c",
    desc: "Tanah vulkanik berapi.",
  },
  {
    id: "sky",
    name: "Langit",
    emoji: "☁️",
    unlockStreak: 30,
    skyTop: "#60a5fa",
    skyBottom: "#bfdbfe",
    ground: "#dbeafe",
    accent: "#3b82f6",
    desc: "Melayang di atas awan.",
  },
  {
    id: "crystal",
    name: "Gua Kristal",
    emoji: "💎",
    unlockStreak: 45,
    skyTop: "#a78bfa",
    skyBottom: "#ddd6fe",
    ground: "#4c1d95",
    accent: "#7c3aed",
    desc: "Gua kristal berkilau.",
  },
  {
    id: "ocean",
    name: "Pantai",
    emoji: "🏖️",
    unlockStreak: 60,
    skyTop: "#38bdf8",
    skyBottom: "#7dd3fc",
    ground: "#fde68a",
    accent: "#0ea5e9",
    desc: "Pantai berpasir cerah.",
  },
];

// ===== Accessories / Items catalog =====
export interface ItemInfo {
  id: string;
  name: string;
  icon: string; // emoji
  type: "accessory" | "background" | "effect" | "food" | "medicine" | "gamepass" | "skin";
  rarity: Rarity;
  price: number;
  currency: "coins" | "gems";
  desc: string;
  effect?: string; // functional effect id
}

export const ITEMS: ItemInfo[] = [
  // Accessories
  { id: "hat_topi", name: "Topi Petualang", icon: "🎩", type: "accessory", rarity: "common", price: 50, currency: "coins", desc: "Topi klasik bergaya." },
  { id: "hat_kacamata", name: "Kacamata Hitam", icon: "🕶️", type: "accessory", rarity: "rare", price: 120, currency: "coins", desc: "Kacamata hemat keren." },
  { id: "hat_mahkota", name: "Mahkota Raja", icon: "👑", type: "accessory", rarity: "epic", price: 40, currency: "gems", desc: "Mahkota untuk raja naga." },
  { id: "hat_pedang", name: "Pedang Kayu", icon: "🗡️", type: "accessory", rarity: "common", price: 80, currency: "coins", desc: "Pedang mainan lucu." },
  { id: "hat_pita", name: "Pita Manis", icon: "🎀", type: "accessory", rarity: "rare", price: 100, currency: "coins", desc: "Pita merah muda." },
  { id: "hat_topi_pesta", name: "Topi Pesta", icon: "🥳", type: "accessory", rarity: "common", price: 60, currency: "coins", desc: "Topi pesta warna-warni." },
  { id: "hat_halo", name: "Halo Malaikat", icon: "😇", type: "accessory", rarity: "legendary", price: 80, currency: "gems", desc: "Halo bercahaya suci." },
  { id: "hat_tanduk", name: "Tanduk Iblis", icon: "😈", type: "accessory", rarity: "epic", price: 50, currency: "gems", desc: "Tanduk jahat nan keren." },
  // Food
  { id: "food_apple", name: "Apel", icon: "🍎", type: "food", rarity: "common", price: 10, currency: "coins", desc: "Makanan biasa, +20 kenyang.", effect: "feed20" },
  { id: "food_meat", name: "Daging", icon: "🍖", type: "food", rarity: "common", price: 25, currency: "coins", desc: "Daging mengenyangkan, +45 kenyang.", effect: "feed45" },
  { id: "food_fish", name: "Ikan", icon: "🐟", type: "food", rarity: "rare", price: 40, currency: "coins", desc: "Ikan segar, +60 kenyang & mood naik.", effect: "feed60" },
  { id: "food_gemfruit", name: "Buah Permata", icon: "💎", type: "food", rarity: "legendary", price: 5, currency: "gems", desc: "Buah langka, kenyang penuh & mood max!", effect: "feed100" },
  // Medicine
  { id: "med_syrup", name: "Obat Penyakit", icon: "💊", type: "medicine", rarity: "rare", price: 60, currency: "coins", desc: "Sembuhkan naga dari sakit.", effect: "cure" },
  { id: "med_mood", name: "Tonik Mood", icon: "🧪", type: "medicine", rarity: "rare", price: 80, currency: "coins", desc: "Mood naik ke 100.", effect: "moodmax" },
  { id: "med_energy", name: "Energy Drink", icon: "⚡", type: "medicine", rarity: "rare", price: 70, currency: "coins", desc: "Energi penuh kembali.", effect: "energymax" },
  // Gamepass
  { id: "gp_double", name: "Gamepass 2x Tumbuh", icon: "🚀", type: "gamepass", rarity: "epic", price: 50, currency: "gems", desc: "Pertumbuhan 2x lebih cepat selamanya.", effect: "doublegrowth" },
  { id: "gp_shield", name: "Perisai Streak", icon: "🛡️", type: "gamepass", rarity: "epic", price: 45, currency: "gems", desc: "Lindungi streak dari reset 1x.", effect: "shield" },
];

export function getItem(id: string): ItemInfo | undefined {
  return ITEMS.find((i) => i.id === id);
}

// ===== Streak Rewards (chests) =====
export interface StreakRewardInfo {
  day: number;
  chest: "common" | "rare" | "epic";
  label: string;
}

export const STREAK_REWARDS: StreakRewardInfo[] = [
  { day: 3, chest: "common", label: "Peti Biasa" },
  { day: 7, chest: "rare", label: "Peti Langka" },
  { day: 14, chest: "common", label: "Peti Biasa" },
  { day: 21, chest: "rare", label: "Peti Langka" },
  { day: 30, chest: "epic", label: "Peti Epik" },
  { day: 45, chest: "rare", label: "Peti Langka" },
  { day: 60, chest: "epic", label: "Peti Epik" },
  { day: 100, chest: "epic", label: "Peti Epik Spesial" },
];

// ===== Chest contents pools =====
export const CHEST_POOLS: Record<
  "common" | "rare" | "epic",
  { itemIds: string[]; coinRange: [number, number]; gemRange: [number, number]; itemCount: number }
> = {
  common: {
    itemIds: ["hat_topi", "hat_pedang", "hat_topi_pesta", "food_apple", "food_meat"],
    coinRange: [30, 80],
    gemRange: [0, 1],
    itemCount: 2,
  },
  rare: {
    itemIds: ["hat_kacamata", "hat_pita", "hat_mahkota", "food_fish", "med_syrup", "med_mood"],
    coinRange: [80, 200],
    gemRange: [1, 3],
    itemCount: 2,
  },
  epic: {
    itemIds: ["hat_halo", "hat_tanduk", "hat_mahkota", "food_gemfruit", "med_energy", "gp_shield"],
    coinRange: [200, 500],
    gemRange: [3, 8],
    itemCount: 3,
  },
};

// ===== Achievements =====
export interface AchievementInfo {
  id: string;
  name: string;
  desc: string;
  icon: string;
}

export const ACHIEVEMENTS: AchievementInfo[] = [
  { id: "first_egg", name: "Telur Pertama", desc: "Mulai petualangan dengan telur pertama.", icon: "🥚" },
  { id: "seven_days", name: "7 Hari", desc: "Pertahankan streak 7 hari.", icon: "🔥" },
  { id: "first_evo", name: "Evolusi Pertama", desc: "Naga menetas dari telur.", icon: "🐲" },
  { id: "bond_50", name: "Sahabat Sejati", desc: "Capai bond level 50.", icon: "❤️" },
  { id: "hundred_days", name: "100 Hari", desc: "Pertahankan streak 100 hari.", icon: "💯" },
  { id: "dragon_king", name: "Raja Naga", desc: "Capai Naga Super Kuat.", icon: "👑" },
  { id: "mutant", name: "Bermutasi", desc: "Naga bermutasi elemen.", icon: "🧬" },
  { id: "collector", name: "Kolektor", desc: "Miliki 8 item di inventory.", icon: "🎒" },
  { id: "rich", name: "Kaya Raya", desc: "Kumpulkan 1000 koin.", icon: "💰" },
  { id: "legacy_3", name: "Generasi ke-3", desc: "Naik ke generasi naga ke-3.", icon: "🏛️" },
  { id: "explorer", name: "Penjelajah", desc: "Buka 4 area berbeda.", icon: "🗺️" },
  { id: "minigamer", name: "Jago Mini Game", desc: "Mainkan mini game 10x.", icon: "🎮" },
];

// ===== Mission templates =====
export const MISSION_TEMPLATES: { type: Mission["type"]; desc: (n: number) => string; targets: number[]; rewardCoins: [number, number]; rewardGems: number }[] = [
  { type: "pet", desc: (n) => `Elus naga ${n}x`, targets: [3, 5, 8], rewardCoins: [30, 60], rewardGems: 0 },
  { type: "feed", desc: (n) => `Beri makan ${n}x`, targets: [2, 3, 4], rewardCoins: [40, 80], rewardGems: 0 },
  { type: "play", desc: (n) => `Main sama naga ${n}x`, targets: [2, 3, 5], rewardCoins: [35, 70], rewardGems: 0 },
  { type: "clean", desc: (n) => `Bersihkan kotoran ${n}x`, targets: [1, 2, 3], rewardCoins: [25, 50], rewardGems: 0 },
  { type: "click", desc: (n) => `Klik naga ${n}x`, targets: [10, 20, 30], rewardCoins: [20, 40], rewardGems: 0 },
  { type: "minigame", desc: (n) => `Mainkan mini game ${n}x`, targets: [1, 2, 3], rewardCoins: [50, 100], rewardGems: 1 },
];

// ===== Dragon dialogues (bubble chat) by mood =====
export const DIALOGUES: Record<string, string[]> = {
  happy: [
    "Aku senang hari ini!",
    "Kau menyenangkan, partner!",
    "Hari yang indah ya?",
    "Aku cinta kau, manusia!",
    "Yuk bermain lagi!",
    "Perutku penuh, syukur!",
    "Moodku lagi enak nih.",
    "Terima kasih sudah jagaku!",
  ],
  angry: [
    "Aku marah! Hmph!",
    "Kenapa lama banget?!",
    "Lapar nih, cepat dong!",
    "Aku ngambek nih...",
    "Jangan tinggal aku lagi!",
    "Hmph! Aku kesel!",
  ],
  sad: [
    "Aku sedih...",
    "Kau kemana saja?",
    "Aku merasa kesepian...",
    "Lapar... tapi sedih...",
    "Aku rindu kau...",
    "Tolong temani aku...",
  ],
  anxious: [
    "Aku gelisah...",
    "Ada yang aneh...",
    "Aku tidak enak...",
    "Tolong aku...",
    "Aku takut...",
    "Perutku sakit...",
  ],
  sick: [
    "Aku... sakit...",
    "Tolong... obat...",
    "Aku tidak enak badan...",
    "Sakit... perut...",
    "Tolong sembuhkan aku...",
    "Aku lemas sekali...",
  ],
  sleeping: [
    "Zzz... enaknya...",
    "Zzz... makan... besar...",
    "Hmm... mimpi indah...",
    "Zzz... ngorok...",
    "Tidur... nyenyak...",
  ],
  hungry: [
    "Aku lapar!",
    "Makanan dong, cepat!",
    "Perutku keroncongan!",
    "Aku mau makan!",
    "Lapar banget nih!",
    "Kasih makan donk!",
  ],
  greeting: [
    "Halo kembali!",
    "Aku mencarimu tadi...",
    "Akhirnya kau datang!",
    "Kemana aja sih?",
    "Kau kembali! Senangnya!",
  ],
  long_gone: [
    "Kupikir kau tak kembali...",
    "Aku menunggu lama sekali...",
    "Jangan tinggal aku selama itu lagi!",
    "Aku hampir putus asa...",
  ],
  ghost: [
    "Aku dulu hidup 78 hari...",
    "Dunia ini indah dulu...",
    "Jaga generasi berikutnya...",
    "Aku bangga padamu...",
    "Kenangan kita... abadi...",
  ],
};

// ===== Random dragon activities =====
export const ACTIVITIES = [
  "berjalan-jalan",
  "merentangkan sayap",
  "melihat sekeliling",
  "menguap panjang",
  "mengibas ekor",
  "bermain sendiri",
  "mengendus-ngendus",
  "berputar-putar",
];

// ===== Mood thresholds =====
export const MOOD_THRESHOLDS = {
  // given hunger/mood/sick, determine effective mood
  HAPPY_MIN: 70,
  SAD_MAX: 35,
};

// ===== Gamepass durations =====
export const DOUBLE_GROWTH_DURATION = 30 * DAY_MS; // 30 days of double growth

// ===== Mission reset interval =====
export const MISSION_RESET_MS = 3 * HOUR_MS; // 3 hours

export const MISSION_REROLL_COST = 5; // gems

// ===== Free food per day =====
export const DAILY_FREE_FOOD = 5;
