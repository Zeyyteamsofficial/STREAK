// ===== STREAK — Dragon Pet Game — Types =====
// Made by GabutZ — v1.5

export type DragonStage = 0 | 1 | 2 | 3 | 4 | 5 | 6 | 7;

export type MoodType =
  | "happy"
  | "angry"
  | "sad"
  | "anxious"
  | "sick"
  | "sleeping"
  | "hungry";

export type MutationType =
  | "none"
  | "fire"
  | "ice"
  | "lightning"
  | "nature"
  | "shadow";

export type HealthStatus = "healthy" | "sick" | "dead";

export type AppetiteType = "low" | "normal" | "high";

export type Rarity = "common" | "rare" | "epic" | "legendary";

export interface Dragon {
  name: string;
  skin: string;
  stage: DragonStage;
  eggCreatedAt: number;
  stageStartedAt: number;
  lastFedAt: number;
  lastSickAt: number | null;
  diedAt: number | null;
  hunger: number; // 0-100, 100 = starving
  mood: number; // 0-100, 100 = happiest
  energy: number; // 0-100
  bond: number; // 0-100
  health: HealthStatus;
  weight: number; // 0-100, 50 = ideal
  mutation: MutationType;
  mutationUnlockedAt: number | null;
  poopCount: number;
  lastPoopAt: number;
  accessory: string | null;
  appetite: AppetiteType;
  appetiteChangedAt: number;
  generation: number;
  causeOfDeath: string | null;
}

export interface User {
  name: string;
  createdAt: number;
}

export interface Streak {
  current: number;
  record: number;
  lastCheckIn: number;
  claimedDayRewards: number[];
}

export interface Resources {
  coins: number;
  gems: number;
  food: number;
  lastFoodRefill: number;
}

export interface InventoryItem {
  id: string;
  itemId: string;
  type: "accessory" | "background" | "effect" | "food" | "medicine" | "gamepass" | "skin";
  name: string;
  rarity: Rarity;
  icon: string;
  qty: number;
  equipped?: boolean;
}

export interface AreaState {
  unlocked: string[];
  current: string;
}

export interface Mission {
  id: string;
  desc: string;
  type: "pet" | "feed" | "play" | "clean" | "click" | "minigame";
  target: number;
  progress: number;
  rewardCoins: number;
  rewardGems: number;
  done: boolean;
  claimed: boolean;
}

export interface MissionState {
  missions: Mission[];
  generatedAt: number;
  rerollCost: number;
}

export interface AchievementState {
  unlocked: string[];
}

export interface DragonRecord {
  id: string;
  name: string;
  daysLived: number;
  stage: DragonStage;
  mutation: MutationType;
  generation: number;
  diedAt: number;
  cause: string;
  skin: string;
}

export interface Legacy {
  generation: number;
  bonus: number;
  recordDays: number;
  totalDragons: number;
}

export interface GamepassState {
  owned: string[];
  doubleGrowthUntil: number;
}

export interface Stats {
  totalFood: number;
  totalClicks: number;
  totalPets: number;
  totalPlays: number;
  totalCleaned: number;
  totalCoinsEarned: number;
  totalGemsEarned: number;
  miniGamesPlayed: number;
  daysActive: number;
  chestsOpened: number;
}

export interface Settings {
  sound: boolean;
  music: boolean;
  voice: boolean;
}

export interface ActiveEvent {
  id: string;
  type: "rain" | "birthday" | "meteor" | "gift";
  startedAt: number;
  endsAt: number;
}

export interface BubbleChat {
  text: string;
  shownAt: number;
  mood: MoodType;
}

export interface ChestReward {
  chestType: "common" | "rare" | "epic";
  items: { itemId: string; name: string; icon: string; rarity: Rarity; type: string }[];
  coins: number;
  gems: number;
}

export interface GameState {
  version: string;
  user: User | null;
  dragon: Dragon | null;
  streak: Streak;
  resources: Resources;
  inventory: InventoryItem[];
  areas: AreaState;
  missions: MissionState;
  achievements: AchievementState;
  history: DragonRecord[];
  legacy: Legacy;
  gamepass: GamepassState;
  stats: Stats;
  settings: Settings;
  events: ActiveEvent[];
  lastSeen: number;
  bubble: BubbleChat | null;
  pendingReward: ChestReward | null;
  pendingMutation: boolean;
  ghostShown: boolean;
  introSeen: boolean;
}
