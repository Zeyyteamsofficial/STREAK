"use client";
// ===== STREAK — Main Game Hook =====
import { useState, useEffect, useRef, useCallback, useMemo } from "react";
import type { GameState, MutationType } from "./types";
import { loadState, saveState } from "./storage";
import * as engine from "./engine";
import {
  setSoundEnabled, setMusicEnabled, setVoiceEnabled,
  sfxClick, sfxFeed, sfxPet, sfxEvolve, sfxReward, sfxDeath, sfxError, sfxCoin,
  dragonVoice, speak, playMusic, stopMusic, rainSfx,
} from "./audio";
import { isNight } from "./engine";

export function useGame() {
  const [state, setState] = useState<GameState | null>(null);
  const stateRef = useRef<GameState | null>(null);
  const toastFn = useRef<((msg: string, type?: "info" | "success" | "error" | "achievement") => void) | null>(null);

  // keep ref in sync
  useEffect(() => {
    stateRef.current = state;
  }, [state]);

  // toast registration
  const registerToast = useCallback((fn: (msg: string, type?: "info" | "success" | "error" | "achievement") => void) => {
    toastFn.current = fn;
  }, []);

  const toast = useCallback((msg: string, type?: "info" | "success" | "error" | "achievement") => {
    if (msg) toastFn.current?.(msg, type);
  }, []);

  // ===== Load on mount =====
  useEffect(() => {
    const loaded = loadState();
    // apply settings to audio
    setSoundEnabled(loaded.settings.sound);
    setMusicEnabled(loaded.settings.music);
    setVoiceEnabled(loaded.settings.voice);

    // generate missions if none
    if (loaded.missions.missions.length === 0) {
      loaded.missions = { missions: engine.generateMissions(), generatedAt: Date.now(), rerollCost: 5 };
    }

    setState(loaded);
    stateRef.current = loaded;

    // Return message if left alone
    if (loaded.dragon && loaded.dragon.health !== "dead") {
      const returnMsg = engine.getReturnMessage(loaded);
      if (returnMsg) {
        setTimeout(() => {
          toast(returnMsg, "info");
          speak(returnMsg);
        }, 1500);
      }
    }
     
  }, []);

  // ===== Persist on change =====
  useEffect(() => {
    if (state) saveState(state);
  }, [state]);

  // ===== Apply settings to audio when changed =====
  useEffect(() => {
    if (!state) return;
    setSoundEnabled(state.settings.sound);
    setMusicEnabled(state.settings.music);
    setVoiceEnabled(state.settings.voice);
  }, [state?.settings]);

  // ===== Game loop =====
  useEffect(() => {
    if (!state) return;
    const interval = setInterval(() => {
      setState((prev) => {
        if (!prev) return prev;
        let next = engine.tick(prev);
        next = engine.clearExpiredEvents(next);
        next = engine.maybeSpawnEvent(next);
        next = engine.checkAreaUnlocks(next).state;
        // detect evolution
        if (prev.dragon && next.dragon && prev.dragon.stage !== next.dragon.stage) {
          sfxEvolve();
          speak(`${next.dragon.name} berevolusi!`);
          toast(`🎉 ${next.dragon.name} berevolusi menjadi ${engineStageName(next.dragon.stage)}!`, "achievement");
        }
        // detect death
        if (prev.dragon && next.dragon && prev.dragon.health !== "dead" && next.dragon.health === "dead") {
          sfxDeath();
          speak(`${next.dragon.name} telah mati...`);
          next = engine.recordDeath(next);
          toast(`💀 ${next.dragon.name} mati karena ${next.dragon.causeOfDeath}.`, "error");
        }
        // achievements
        const ach = engine.checkAchievements(next);
        if (ach.newlyUnlocked.length > 0) {
          next = ach.state;
          for (const id of ach.newlyUnlocked) {
            const info = achievementName(id);
            toast(`🏅 Achievement: ${info.name}!`, "achievement");
          }
        }
        // mutation unlock
        next = engine.checkMutationUnlock(next);
        // ghost dragon
        next = engine.maybeShowGhost(next);
        // periodic bubble chat
        if (Math.random() < 0.06 && next.dragon && next.dragon.health !== "dead" && !next.bubble) {
          const b = engine.randomBubble(next);
          if (b) {
            next = { ...next, bubble: { text: b.text, shownAt: Date.now(), mood: b.mood } };
          }
        }
        // clear old bubble
        if (next.bubble && Date.now() - next.bubble.shownAt > 5000) {
          next = { ...next, bubble: null };
        }
        return next;
      });
    }, 3000);
    return () => clearInterval(interval);
     
  }, [state !== null]);

  // ===== Music management (day/night/rain) =====
  useEffect(() => {
    if (!state) return;
    if (!state.settings.music) {
      stopMusic();
      return;
    }
    const raining = state.events.some((e) => e.type === "rain");
    if (raining) {
      playMusic("rain");
    } else if (isNight()) {
      playMusic("night");
    } else {
      playMusic("day");
    }
  }, [state?.settings.music, state?.events, state?.areas.current]);

  // rain sfx occasionally
  useEffect(() => {
    if (!state) return;
    const raining = state.events.some((e) => e.type === "rain");
    if (!raining || !state.settings.sound) return;
    const i = setInterval(() => rainSfx(), 2000);
    return () => clearInterval(i);
  }, [state?.events, state?.settings.sound]);

  // ===== Actions =====
  const startGame = useCallback((playerName: string, dragonName: string) => {
    setState((prev) => {
      const base = prev || engine.createInitialState();
      return {
        ...base,
        user: { name: playerName.trim() || "Pemain", createdAt: Date.now() },
        dragon: engine.createDragon(dragonName.trim() || "Naga", base.legacy.generation),
        introSeen: true,
      };
    });
    sfxReward();
    speak(`Selamat datang! Rawat nagamu dengan baik!`);
    toast(`🐣 Telur naga menetas dalam 1 hari. Jaga terus!`, "success");
  }, [toast]);

  const feed = useCallback((amount: number) => {
    setState((prev) => {
      if (!prev || !prev.dragon) return prev;
      const res = engine.feedDragon(prev, amount);
      if (res.ok) {
        sfxFeed();
        const mood = engine.effectiveMood(res.state.dragon!);
        dragonVoice(mood.type);
        toast(res.msg, "success");
      } else {
        sfxError();
        dragonVoice("sad");
        toast(res.msg, "error");
      }
      return res.state;
    });
  }, [toast]);

  const feedFree = useCallback(() => {
    setState((prev) => {
      if (!prev || !prev.dragon) return prev;
      if (prev.resources.food <= 0) {
        toast("Makanan gratis habis! Beli di toko atau tunggu besok.", "error");
        sfxError();
        return prev;
      }
      const newRes = { ...prev.resources, food: prev.resources.food - 1 };
      const res = engine.feedDragon({ ...prev, resources: newRes }, 50);
      if (res.ok) {
        sfxFeed();
        const mood = engine.effectiveMood(res.state.dragon!);
        dragonVoice(mood.type);
        toast(res.msg, "success");
      } else {
        sfxError();
        dragonVoice("sad");
        toast(res.msg, "error");
      }
      return res.state;
    });
  }, [toast]);

  const pet = useCallback(() => {
    setState((prev) => {
      if (!prev || !prev.dragon) return prev;
      const res = engine.petDragon(prev);
      sfxPet();
      const mood = engine.effectiveMood(res.state.dragon!);
      if (mood.type !== "sleeping") dragonVoice(mood.type);
      toast(res.msg, "info");
      return res.state;
    });
  }, [toast]);

  const play = useCallback(() => {
    setState((prev) => {
      if (!prev || !prev.dragon) return prev;
      const res = engine.playWithDragon(prev);
      sfxClick();
      toast(res.msg, "info");
      return res.state;
    });
  }, [toast]);

  const clean = useCallback(() => {
    setState((prev) => {
      if (!prev || !prev.dragon) return prev;
      const res = engine.cleanPoop(prev);
      sfxClick();
      toast(res.msg, "info");
      return res.state;
    });
  }, [toast]);

  const clickDragon = useCallback(() => {
    setState((prev) => {
      if (!prev || !prev.dragon) return prev;
      const res = engine.clickDragon(prev);
      sfxClick();
      return res.state;
    });
  }, []);

  const dailyCheckIn = useCallback(() => {
    setState((prev) => {
      if (!prev) return prev;
      const res = engine.dailyCheckIn(prev);
      sfxCoin();
      if (res.reward) {
        sfxReward();
      }
      toast(res.msg, res.reward ? "achievement" : "info");
      return res.state;
    });
  }, [toast]);

  const claimMission = useCallback((id: string) => {
    setState((prev) => {
      if (!prev) return prev;
      const res = engine.claimMission(prev, id);
      sfxCoin();
      toast(res.msg, "success");
      return res.state;
    });
  }, [toast]);

  const rerollMissions = useCallback(() => {
    setState((prev) => {
      if (!prev) return prev;
      const res = engine.rerollMissions(prev);
      if (res.ok) {
        sfxReward();
        toast(res.msg, "success");
      } else {
        sfxError();
        toast(res.msg, "error");
      }
      return res.state;
    });
  }, [toast]);

  const buyItem = useCallback((itemId: string) => {
    setState((prev) => {
      if (!prev) return prev;
      const res = engine.buyItem(prev, itemId);
      if (res.ok) {
        sfxCoin();
        toast(res.msg, "success");
      } else {
        sfxError();
        toast(res.msg, "error");
      }
      return res.state;
    });
  }, [toast]);

  const buySkin = useCallback((skinId: string) => {
    setState((prev) => {
      if (!prev) return prev;
      const res = engine.buySkin(prev, skinId);
      if (res.ok) {
        sfxReward();
        toast(res.msg, "success");
      } else {
        sfxError();
        toast(res.msg, "error");
      }
      return res.state;
    });
  }, [toast]);

  const equipSkin = useCallback((skinId: string) => {
    setState((prev) => {
      if (!prev) return prev;
      const res = engine.equipSkin(prev, skinId);
      if (res.ok) { sfxClick(); toast(res.msg, "success"); }
      else { sfxError(); toast(res.msg, "error"); }
      return res.state;
    });
  }, [toast]);

  const equipAccessory = useCallback((itemId: string) => {
    setState((prev) => {
      if (!prev) return prev;
      const res = engine.equipAccessory(prev, itemId);
      if (res.ok) { sfxClick(); toast(res.msg, "success"); }
      else { sfxError(); toast(res.msg, "error"); }
      return res.state;
    });
  }, [toast]);

  const useItem = useCallback((itemId: string) => {
    setState((prev) => {
      if (!prev) return prev;
      const res = engine.useItem(prev, itemId);
      if (res.ok) { sfxFeed(); toast(res.msg, "success"); }
      else { sfxError(); toast(res.msg, "error"); }
      return res.state;
    });
  }, [toast]);

  const renameDragon = useCallback((name: string) => {
    setState((prev) => {
      if (!prev) return prev;
      sfxClick();
      toast("Nama naga diganti!", "success");
      return engine.renameDragon(prev, name);
    });
  }, [toast]);

  const changeArea = useCallback((areaId: string) => {
    setState((prev) => {
      if (!prev) return prev;
      const res = engine.changeArea(prev, areaId);
      if (res.ok) { sfxClick(); toast(res.msg, "success"); }
      else { sfxError(); toast(res.msg, "error"); }
      return res.state;
    });
  }, [toast]);

  const applyMutation = useCallback((mut: MutationType) => {
    setState((prev) => {
      if (!prev) return prev;
      sfxEvolve();
      speak("Naga bermutasi!");
      toast(`🧬 Naga bermutasi menjadi elemen ${mut}!`, "achievement");
      return engine.applyMutation(prev, mut);
    });
  }, [toast]);

  const retryDragon = useCallback((name: string) => {
    setState((prev) => {
      if (!prev) return prev;
      sfxEvolve();
      speak("Generasi baru dimulai!");
      toast(`🐣 Telur naga generasi ${prev.legacy.generation} baru!`, "success");
      return engine.retryDragon(prev, name);
    });
  }, [toast]);

  const collectEvent = useCallback((eventId: string) => {
    setState((prev) => {
      if (!prev) return prev;
      const res = engine.collectEventReward(prev, eventId);
      sfxReward();
      toast(res.msg, "success");
      return res.state;
    });
  }, [toast]);

  const giveMiniGameReward = useCallback((score: number) => {
    setState((prev) => {
      if (!prev) return prev;
      const res = engine.giveMiniGameReward(prev, score);
      sfxCoin();
      toast(res.msg, "success");
      return res.state;
    });
  }, [toast]);

  const claimPendingReward = useCallback(() => {
    setState((prev) => {
      if (!prev || !prev.pendingReward) return prev;
      const next = engine.applyReward(prev, prev.pendingReward);
      sfxReward();
      toast("🎁 Hadiah peti dibuka!", "achievement");
      return next;
    });
  }, [toast]);

  const updateSettings = useCallback((settings: Partial<GameState["settings"]>) => {
    setState((prev) => {
      if (!prev) return prev;
      const next = engine.updateSettings(prev, settings);
      setSoundEnabled(next.settings.sound);
      setMusicEnabled(next.settings.music);
      setVoiceEnabled(next.settings.voice);
      return next;
    });
  }, []);

  const dismissBubble = useCallback(() => {
    setState((prev) => (prev ? { ...prev, bubble: null } : prev));
  }, []);

  const dismissGhost = useCallback(() => {
    setState((prev) => (prev ? { ...prev, ghostShown: false } : prev));
  }, []);

  const resetGame = useCallback(() => {
    if (typeof window !== "undefined") {
      if (!window.confirm("Yakin reset SEMUA progress? Ini tidak bisa dibatalkan!")) return;
    }
    const fresh = engine.createInitialState();
    fresh.missions = { missions: engine.generateMissions(), generatedAt: Date.now(), rerollCost: 5 };
    setState(fresh);
    saveState(fresh);
    toast("Game direset total.", "info");
  }, [toast]);

  return {
    state,
    startGame,
    feed,
    feedFree,
    pet,
    play,
    clean,
    clickDragon,
    dailyCheckIn,
    claimMission,
    rerollMissions,
    buyItem,
    buySkin,
    equipSkin,
    equipAccessory,
    useItem,
    renameDragon,
    changeArea,
    applyMutation,
    retryDragon,
    collectEvent,
    giveMiniGameReward,
    claimPendingReward,
    updateSettings,
    dismissBubble,
    dismissGhost,
    resetGame,
    registerToast,
  };
}

function engineStageName(stage: number): string {
  const names = ["Telur Naga", "Bayi Naga", "Bayi Naga Besar", "Anak Naga", "Naga Remaja", "Naga Biasa", "Naga Kuat", "NAGA SUPER KUAT"];
  return names[stage] || "Naga";
}

function achievementName(id: string): { name: string } {
  const map: Record<string, { name: string }> = {
    first_egg: { name: "Telur Pertama" },
    seven_days: { name: "7 Hari" },
    first_evo: { name: "Evolusi Pertama" },
    bond_50: { name: "Sahabat Sejati" },
    hundred_days: { name: "100 Hari" },
    dragon_king: { name: "Raja Naga" },
    mutant: { name: "Bermutasi" },
    collector: { name: "Kolektor" },
    rich: { name: "Kaya Raya" },
    legacy_3: { name: "Generasi ke-3" },
    explorer: { name: "Penjelajah" },
    minigamer: { name: "Jago Mini Game" },
  };
  return map[id] || { name: id };
}
